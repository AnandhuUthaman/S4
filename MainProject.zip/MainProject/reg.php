<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>CharitABLE | Registration Form</title>
    <link rel="stylesheet" href="reg.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--<script type="text/javascript">
        function optionCheck(dopt) {
        var selectedValue = dopt.options[dopt.selectedIndex].value;
        var txtOther = document.getElementById("txtOther");
        txtOther.disabled = selectedValue == 5 ? false : true;
        if (!txtOther.disabled) {
            txtOther.focus();
        }
    }
</script>-->
<!-----<script>
function rePlace() {
  location.replace("C:\xampp1\htdocs\MainProject\reg.php")
}    

</script>--->
<style>
    .dropbtn {
      background-color: white;
      color: black;
      padding: 0px;
      font-size: 1.12rem;
      font-weight: 1rem;
      border: none;
      cursor: pointer;
    }

    .dropdown {
      margin-left: 11px;
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      z-index: 1;
    }

    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {
      background-color: #f1f1f1
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown:hover .dropbtn {
      color: #ff7300;
    }
  </style>
</head>
<body>
<div style="width:100%; height:30px; background-color:darkblue; color:white; font-size:13px; position: relative;">
    <div style="margin-left:120px;">&#9993 charitable@gmail.com&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&#9990 +91 6238591004&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-twitter"></i>      <i class="fas fa-facebook"></i>
</div>
<header>
    
<nav>
    
     
    <ul>
           <li><a href="#" class="logo">CharitABLE</a></li>
           <!--<input class="search" type="text" placeholder="Search..">-->
           <li style="padding-left: 430px;"><a href="index.php">Home</a></li>
           <li><a href="contact.php">Contact us</a></li>
           <li><a href="about.php">About</a></li>
           <li><a href="#">News</a></li>
           <li><a href="login.php">Login</a></li>
           <li><a href="reg.php" class="active">Sign Up</a></li>
    </ul>
      </div>
    </nav>
</header>   
<div class="container">
     <div class="title"><center>Registration</center></div>
         <div class="content">
               <form action="" method="post" enctype="multipart/form-data">
                   <div class="user-details">
                           <div class="input-box">
                                <span class="details">First Name</span>
                                <input type="text" id="fname" name="fname" placeholder="Enter First name" required>
                           </div>
                           <div class="input-box">
                                <span class="details">Last name</span>
                                <input type="text" id="lname" name="lname" placeholder="Enter Last name" required>
                           </div>
                           <div class="input-box">
                                <span class="details">Aadhar number</span>
                                <input type="text" id="ano" name="ano" placeholder="Enter Aadhar number" required>
                           </div>
                           <div class="input-box">
                                <span class="details">House name</span>
                                <input type="text" id="hname" name="hname" placeholder="Enter House name" required>
                           </div>
                           <div class="input-box">
                                <span class="details">Place</span>
                                <input type="text" id="place" name="place" placeholder="Enter your Place" required>
                           </div>
<div class="input-box">
    <span class="details">District</span>
  
    <select id="dopt" name="dopt" >   
    <option name="District" value="none" selected disabled hidden>Select District</option> 
    <option name="Kottayam">Kottayam</option>
    <option name="Idukki">Idukki</option>
    <option name="Kollam">Kollam</option>
    <option name="Alappuzha">Alapuzha</option>
    <option name="Trivandrum">Trivandrum</option>
    <option name="Ernakulam">Ernakulam</option>
    <option name="Pathanamthitta">Pathanamthitta</option>
    <option name="Thrissur">Thrissur</option>
    <option name="Palakkad">Palakkad</option>
    <option name="Kozhikkode">Kozhikkod</option>
    <option name="Kannur">Kannur</option>
    <option name="Wayanad">Wayanad</option>
    <option name="Malappuram">Malappuram</option>
    <option name="Kasargod">Kasargod</option>
    </select>
</div>
      <div class="input-box">
            <span class="details">Phone number</span>
            <input type="text" id="phno" name="phno" placeholder="Enter Phone number" required>
      </div>
      <div class="input-box">
            <span class="details">Email id</span>
            <input type="text" id="email" name="email" placeholder="Enter your email" required>
      </div>
      <div class="input-box">
            <span class="details">Password</span>
            <input type="password" id="psw" name="psw" placeholder="Enter your password" required>
      </div>  
      <div class="input-box">
            <span class="details">Confirm Password</span>
            <input type="password" id="rpsw" name="rpsw" placeholder="Confirm your password" required>
      </div>
<div class="input-area" style="color:black;"><label>Upload Image </label>
    <input type="file" name="image" id="image">
</div>
                     </div>
      <div class="input-box">
            <span class="details">Role</span>
  
                <select id="role" name="role" required>   
                <option name="Role" value="none" selected disabled hidden>Select Role</option> 
                <option name="donor">Donor</option>
                <option name="volunteer">Volunteer</option>
                <option name="client">Client</option>
      </div>
     
      <div>
                <div class="gender-details">
                     <input type="radio" name="gender"value="male" id="dot-1">
                     <input type="radio" name="gender"value="female" id="dot-2">
                     <input type="radio" name="gender"value="other" id="dot-3">
                     <br><br>
                          <span class="gender-title" style="color: black; margin-right:450px;">Gender</span>
                     <div class="category">
                          <label for="dot-1">
                               <span class="dot one"></span>
                               <span class="gender">Male</span>
                          </label>
                          <label for="dot-2">
                               <span class="dot two"></span>
                               <span class="gender">Female</span>
                          </label>
                          <label for="dot-3">
                               <span class="dot three"></span>
                               <span class="gender">Other</span>
                          </label>
                          
               </div></div>
          

                <div class="button" align="center">
                    <input type="submit" name="submit" value="Register">

               </div> 
       </div>

    </div>
  </div>
  
</form>
</div>

<!---<div style="width: 100%; height: 200px; background-color: whitesmoke; position: relative;">
    <div style="width:230px; height: 100px; color: indigo; font-size: 1.7rem; margin-top: 0px; margin-left: 70px;"><h3>Charit<span>ABLE</span></h3></div>
</div>---->

</body>
</html>
<?php

include('config.php');

if(isset($_POST['submit']))
{


	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$ano=$_POST['ano'];
	$hname=$_POST['hname'];
	$place=$_POST['place'];
	$phno=$_POST['phno'];
	$dist=$_POST['dopt'];
	$psw=$_POST['psw'];
	$rpsw=$_POST['rpsw'];
	$email=$_POST['email'];
	//$image=$_POST['image'];

	
  $gender=$_POST['gender'];
	$role=$_POST['role'];



//input fields are Validated with regular expression
$validName="/^[a-zA-Z ]*$/";
$validEmail="/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/";
$uppercasePassword = "/(?=.*?[A-Z])/";
$lowercasePassword = "/(?=.*?[a-z])/";
$digitPassword = "/(?=.*?[0-9])/";
$spacesPassword = "/^$|\s+/";
$symbolPassword = "/(?=.*?[#?!@$%^&*-])/";
$specialCharacters = "/(?=.*?[#?!@$%^&*-])/";
$minEightPassword = "/.{8,}/";
$Validphone = "/^[0-9]{11}+$/";
$ValidAadharNumber = "/^[2-9]{1}[0-9]{3}\\s[0-9]{4}\\s[0-9]{4}$/";


//  First Name Validation
if(empty($fname))
{
	  echo '<script>alert("First Name is Required")</script>';
}
if (!preg_match($validName,$fname)) 
{
		echo '<script>alert("Digits are not allowed in First name")</script>';
} 
if (preg_match($specialCharacters,$fname)) 
{
		echo '<script>alert("Special characters are not allowed in First name")</script>';
}
//  Last Name Validation
if(empty($lname))
{
    echo '<script>alert("Last Name is Required")</script>'; 
}
if (!preg_match($validName,$lname)) 
{
    echo '<script>alert("Digits are not allowed in Last name")</script>';
}
if (preg_match($specialCharacters,$fname)) 
{
		echo '<script>alert("Special characters are not allowed in First name")</script>';
}
//Email Address Validation
if(empty($email))
{
    echo '<script>alert("Email is Required")</script>'; 
}
if (!preg_match($validEmail,$email)) 
{
    echo '<script>alert("Invalid Email Address")</script>';
}
 
// password validation 
if(empty($psw))
{
  echo '<script>alert("Password is Required")</script>'; 
} 
if (!preg_match($uppercasePassword,$psw) || !preg_match($lowercasePassword,$psw) || !preg_match($digitPassword,$psw) || !preg_match($symbolPassword,$psw) || !preg_match($minEightPassword,$psw) || preg_match($spacesPassword,$psw)) 
{
  echo '<script>alert("Password must be at least one uppercase letter, lowercase letter, digit, a special character with no spaces and minimum 8 length")</script>';
}

//form validation for confirm password
if(empty($rpsw))
{
    echo '<script>alert("Confirm Password is Required")</script>'; 
} 
if($psw != $rpsw) 
{
    echo '<script>alert("Password and confirm password does not match")</script>';
}
// phone number validation 
if(empty($phno))
{
	  echo '<script>alert("Phone number is Required")</script>';
}
if(preg_match($validName,$phno))
{
		echo '<script>alert("Characters are not allowed in Phone number")</script>';
} 
if(!preg_match($Validphone,$phno)) 
{
    echo '<script>alert("Enter Phone Number with correct format")</script>';
} 
// Aadhar number validation 
if(empty($ano))
{
	  echo '<script>alert("Aadhar number is Required")</script>';
}
if(preg_match($validName,$ano)) 
{
		echo '<script>alert("Characters are not allowed in Aadhar number")</script>';
} 
if(!preg_match($ValidAadharNumber,$ano)) 
{
    echo '<script>alert("Enter Aadhar Number with correct format")</script>';
}   
// House name validation 
if(empty($hname))
{
	  echo '<script>alert("House name is Required")</script>';
}
if(!preg_match($validName,$hname)) 
{
		echo '<script>alert("Digits are not allowed in House name field")</script>';
} 
// Place validation 
if(empty($place))
{
	  echo '<script>alert("Place is Required")</script>';
}
if(!preg_match($validName,$place)) 
{
		echo '<script>alert("Digits are not allowed in Place field")</script>';
}      


	  // If upload button is clicked ...
	
    if(isset($_POST['submit']))
    {
	         $filename = $_FILES["image"]['name'];
           $tempname = $_FILES["image"]["tmp_name"];    
	         move_uploaded_file($tempname,"images/".$filename);
	  }
    if (!empty('$fname') && preg_match($validName,$fname) && !preg_match($specialCharacters,$fname) && !empty('$lname') && preg_match($validName,$lname) && !preg_match($specialCharacters,$lname) && !empty('$email') && preg_match($validEmail,$email) && !empty('$ano') && preg_match($ValidAadharNumber,$ano) && !empty('$hname') && preg_match($validName,$hname) && !empty($place) && preg_match($validName,$place) && !empty($phno) && preg_match($Validphone,$phno) && !empty('$dist') && preg_match($validName,$dist) && !empty('$psw') && preg_match($uppercasePassword,$psw) && preg_match($lowercasePassword,$psw) && preg_match($digitPassword,$psw) && preg_match($symbolPassword,$psw) && preg_match($minEightPassword,$psw) && !empty('$rpsw') && preg_match($uppercasePassword,$rpsw) && preg_match($lowercasePassword,$rpsw) && preg_match($digitPassword,$rpsw) && preg_match($symbolPassword,$rpsw) && preg_match($minEightPassword,$rpsw) && $psw == $rpsw)  
    {


		     $con=mysqli_connect("localhost:3308","root","","charitymain") ;
		     $sql="INSERT INTO `registration`(`fname`, `lname`, `aadhar`, `hname`, `place`, `dist`, `phno`, `psw`, `email`, `gender`, `role`, `img`) VALUES ('$fname', '$lname', '$ano', '$hname', '$place', '$dist', '$phno', '$psw', '$email','$gender','$role','$filename')";

		     if(mysqli_query($con,$sql))
		     {

		           if(($psw==$rpsw))
			         {
			              header('Location:login.php');
			              echo '<script>alert("Registered successfully")</script>';
		           }
			
		     }
		     else
		     {
				            echo '<script>alert("!Registration failed.......")</script>';
			
	    	 }
		
    }
    else
    {
        echo '<script>alert("!Registration failed")</script>';
    }

		
}

?>
