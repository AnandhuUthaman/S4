
<?php

session_start();
 


if (isset($_SESSION["charitymain"]) != session_id()) 
{

    header("Location:../index.php");

    die();

} 
else
{

   if (isset($_SESSION['email'])) 
   { 
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>ChaitABLE | Admin|Dashboard</title>
	<link rel="stylesheet" type="text/css" href="home.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
   <style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	   margin-top: 80px;
      margin-left: 510px;
      color: red;
      width: 500px;
      height: 500px;
      background: whitesmoke;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
    </style>
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
		 <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>
	
	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">&#128274;Logout</button>
</form>
<!------------------------------->
<div id="box" class="snackbar">
   <h4>Notifications</h4>
   <!-- <?php

   ?> -->
   <button><a href="notifications.php" style="text-decoration:none !important;">View Nofications</a></button>
</div>
  <script src="notify.js"></script>
  <!---------------------------------->
		 <a href="feedback.php" class="logoutbtn">&#9993;</a>



		 <a href="notifications.php" for="btn" class="logoutbtn" style="margin-right:100px;">&#128276;</a>
	</div>
	<h1 style="margin-left: 215px; width: 1180px; height: 34px; background-color:rgb(209, 18, 18); text-align: center;">&nbsp;Admin Panel</h1>
</header>
 
  <div class="sidebar">
  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
   <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

  </div>

    <nav>
         <label for="btn" class="button">User credentials
         <span>&#128194;</span>
         </label>
         <input type="checkbox" id="btn">
         <ul class="menu">
            <li><a href="fundApproval.php">Fund approval</a></li>
            <li>
               <label for="btn-2" class="first"><a href="registrationApproval.php">A/C approval</a>
               </label>
               
            </li>
            <li>
               <label for="btn-3" class="second"><a href="issues.php">Issues</a>
               </label>
               
            </li>
            <li><a href="messages.php">Contact</a></li>
            <li><a href="feedback.php">Feedback</a></li>
         </ul>
         
    </nav>
      <!-- This code used to rotate drop icon(-180deg).. -->
      <script>
         $('nav .button').click(function(){
           $('nav .button span').toggleClass("rotate");
         });
           $('nav ul li .first').click(function(){
             $('nav ul li .first span').toggleClass("rotate");
           });
           $('nav ul li .second').click(function(){
             $('nav ul li .second span').toggleClass("rotate");
           });
      </script>
</body>
</html>
<?php
    }
 else
 {
       header('location: ../index.php');
 }
}
?>