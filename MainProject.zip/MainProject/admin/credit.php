<?php
include('config.php');
session_start();
$e = $_SESSION['email'];




if (isset($_SESSION['email'])) 
{
  if(isset($_POST['submit1'])) 
  {
  

  $name = $_POST['name'];
  $card_no = $_POST['cno'];
  $amount = $_POST['amount'];
  $email = $_SESSION['email'];


  $sql = "INSERT INTO `fundgiven`(`famount`,'email') VALUES ('$amount','$email')";
  mysqli_query($con, $sql);

  $sql1 = "UPDATE `fundraise` SET `status`=1 WHERE email=$email";
  mysqli_query($con, $sql1);


  $sq5 = "SELECT * FROM `bankaccount` WHERE email='$email'";
  $sq3 = mysqli_query($con, $sq5);

  if ($row = mysqli_fetch_assoc($sq3)) {
    if ($row['name'] == $name) {
      $sql123 = "SELECT `amount` FROM `bankaccount` WHERE email='$email'";
      $re = mysqli_query($con, $sql123);
      while ($row = mysqli_fetch_assoc($re)) {
        $bal = $row['amount'];
      }
      if ($bal > $amount) {
        $bal1 = $bal - $amount;
        $sql11 = "UPDATE `bankaccount` SET `amount`=$bal1 WHERE email='$email'";
        mysqli_query($con, $sql11);

        echo '<script>alert("!---Payment Successful---!")</script>';
        header('Location:raisedfunds.php');
      } else {
        echo '<script>alert("!---IInsufficient balance---!")</script>';
      }
    } else {
      echo '<script>alert("Invalid")</script>';
    }
  }
  }






?>
<html>

<head>
  <title>ChaitABLE | Admin |Payment</title>
  <link rel="stylesheet" type="text/css" href="credit.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  <header>
    <label for="check">
      <i class="fas fa-bars" id="sidebtn"></i>
      <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
    </label>

    <div class="left">
      <h3>Charit<span>ABLE</span> </h3>
    </div>

    <div class="right" style="margin-top: 10px;">
      <form action="logout.php" method="POST">
        <button type="submit" name="logout" class="logoutbtn" style="margin-left: 900px;">&#128274;Logout</button>
      </form>
      <a href="#" class="logoutbtn" style="margin-right:210px;">&#128276;</a>
      <a href="feedback.php" class="logoutbtn" style="margin-right: 150px;">&#9993;</a>

    </div>
  </header>

  <div class="sidebar">
    <center>
      <?php
      // $e = $_SESSION['email'];

      include('config.php');
      $sql = "select * from registration where email='$e'";

      $sq = mysqli_query($con, $sql);
      while ($row = mysqli_fetch_assoc($sq)) {
      ?>
        <img src="../images/<?php echo $row['img']; ?>" class="profile">

        <h4><?php echo $row['fname']; ?></h4>
      <?php
      }
      ?>
    </center>
    </center>
    <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <<a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

  </div>
  <br>
  <br>
  <br>
  <br>
  <div class="container">

    <h3 align="center">Payment</h3>
    <form action="" method="post">

      <table>
        <tr>
          <label for="fname">Accepted Cards</label>
        </tr>
        <tr>
          <center>
            <div class="icon-container">

              <i class="fa fa-cc-visa" style="color:blue;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
          </center>
        </tr>

        <tr>
          <label for="name">Name on Card</label>
          <input type="text" id="name" name="name" placeholder="John More Doe" required/>
        </tr>
        <tr>
          <label for="cno">Credit card number</label>
          <input type="text" id="ccnum" name="cno" placeholder="1111-2222-3333-4444" required/>
        </tr>

        <label for="expmonth">Exp Month</label>
        <input type="text" id="expmonth" name="expmonth" placeholder="September" required>

        <label for="expmonth">Amount</label>
        <input type="text" id="amount" name="amount" placeholder="Amount" required>

        <label for="expyear">Exp Year</label>
        <input type="text" id="expyear" name="expyear" placeholder="2018" required>

        <label for="cvv">CVV</label>
        <input type="text" id="cvv" name="cvv" placeholder="352" required>
        <br>
        
          <input type="submit" name="submit1" value="Continue Payment" class="btn">
        


      </table>



    </form>
  </div>
</body>
</html>
<?php
}
else
{
    header('location: ../index.php');
}
?>
