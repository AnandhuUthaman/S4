<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{

?>
<!DOCTYPE html>
<html>
<head>
	<title>ChaitABLE | Admin |Notifications</title>
	<link rel="stylesheet" type="text/css" href="notifications.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
         <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;"><i class="fas fa-home"></i></a>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>

	<div class="right" style="margin-top: 10px;">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn" style="margin-left: 900px;">Logout</button>
      <a href="feedback.php" class="logoutbtn" style="margin-right: 150px;"><i class="far fa-envelope"></i></a>
</form>
<a href="feedback.php" class="logoutbtn" style="margin-right: 150px;"><i class="far fa-envelope"></i></a>
<a href="#" class="logoutbtn" style="margin-right:210px;"><i class="fas fa-bell"></i></a>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</header>
 
  <div class="sidebar">
  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
      </center>
    <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

  </div>
  <div class="table_responsive">
  <div class="content">
  <h2 style="margin-left:400px; font-weight:25px; color:black;">Notifications</h2>
  </div>
                <table>         
        
                   <thead>
                            <tr>
                                <th>First name</th>
                                <th>Last name</th>
								<th>Email</th>
                                <th>Message</th>
                                <th>Date</th>
                                <th>Manage</th>
                            </tr></thead>
                        
                       
                                <?php
                                    $sql="SELECT * from feedback";
                                    $res=mysqli_query($con,$sql);
                                    while($row=mysqli_fetch_array($res))
                                    {
                                ?>
                                 <tbody>
                                    <tr>
                                       <p>
                                        <td><?php  echo $row['fname']?></td>
                                        <td><?php  echo $row['lname']?></td>
										<td><?php  echo $row['email']?></td>
                                        <td><?php  echo $row['msg']?></td>
                                        <td><?php  echo $row['date']?></td>
                                        <td>
                                            <?php
                                                 if($row['date'] == date("Y-m-d"))
                                                 {
                                                    echo "Today";
                                                 }
                                                else
                                                {
                                                    echo $row['date'];
                                                }
                                            ?>
                                        </td></p>
                                        <td><a href="clearFeedback.php?$id=<?php echo $row['id']; ?>"><i class="fas fa-trash" style="color: red;"></i></a></td>
                                    </tr>
                                <?php 
                                    }
                                       
                                ?>
                                  <td><a href="clearAllFeedback.php" style="color: red;">Clear&nbsp;all</a></td> 
                        </tbody>
                    </table>
                    
        </div>    

</body>
</html>
<?php
}
else
{
    header('location: ../index.php');
}
?>