<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{


?>
<!DOCTYPE html>
<html lang="en">
<head>

<!--TITLE-->
<title>ChaitABLE | Admin |Change Password</title>

<!--ICON-->
<link rel="shortcut icon" href="/DevanagariBrahmi/logo.png">

<!--META TAGS-->
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="author" content="Team Bboysdreamsfell">
<meta name="description" content="">
<meta name="keywords" content="">
<meta property="og:locale" content="en_US" />
<meta property="og:url" content="" />
<meta property="og:site_name" content="Profiler Name || Krishivalahs" />
<!--EXTERNAL CSS-->
<link rel="stylesheet" href="changePsw.css">



<!--PLUGIN-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

<!--FONT AWESOME-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--GOOGLE FONTS-->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Odibee+Sans&family=Oswald:wght@300;400&family=Ubuntu:wght@700&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Pattaya&display=swap" rel="stylesheet"> 
<body>

<header>
     <label for="check">
      <i class="fas fa-bars" id="sidebtn"></i>
      <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 5px;"><i class="fas fa-home"></i></a>
     </label>
   <div class="left">
      <h3>Charit<span>ABLE</span> </h3>
   </div>

   <div class="right">
      <form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn" style="margin-left: 1100px;">Logout</button>
</form>
<a href="feedback.php" class="logoutbtn" style="margin-right: 150px;"><i class="far fa-envelope"></i></a>
<a href="#" class="logoutbtn" style="margin-right:100px;"><i class="fas fa-bell"></i></a>
      <!--<a href="logout.php" class="logoutbtn" name="logout">Logout</a>--->
   </div>
</header>
 
  <div class="sidebar">
  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    
  	</center>
    <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

   
  </div>

<div class="container" style="margin-left:330px; background-color:Black;">
<form action="" method="POST"><table >
<tr>
<td>
<ul style="margin-top:150px;">
<li><b>Password</b>  <input type="text" name="psw" id="psw" maxlength="100" value="" required /></li>
<li><b style="margin-left:57px;">Retype Password</b> <input type="text" name="rpsw" id="rpsw" maxlength="100" value="" required /></li>
    
</div>
</tr>
<tr>
    <td><li><input type="submit", value="Submit" name="submit" class="btn_submit"></li></td>
</tr>
</table ></form>
<?php
	}
?>
<!--JAVASCRIPT-->
<script src="js/custom.js"></script>
<script>
function editdetails2(){
}

var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
  close[i].onclick = function(){
    var div = this.parentElement;
    div.style.opacity = "0";
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
</body>
</html>
<?php
include('config.php');
if(isset($_POST['submit']))
{
    
    
    $email=$_SESSION['email'];
    $psw=$_POST['psw'];
    $rpsw=$_POST['rpsw'];

    $sql="SELECT * FROM `registration` WHERE email='$email'";
    $re=mysqli_query($con,$sql);
    if($row = mysqli_fetch_array($re))
    {
        if($row['email'] == $email)
        {
            if($psw == $rpsw)
            {
                $sq="UPDATE `registration` SET `psw`='$psw' WHERE email='$email'";
                mysqli_query($con,$sq);

                echo '<script>alert("Changed")</script>';
                
            }
            else
            {
                echo '<script>alert("Password and Retype password field must be same")</script>';
            }
        }
    }    
        else
        {
            echo '<script>alert("Not changed.")</script>';
            
        }
}
?>  
<?php
}
else
{
    header('location: ../index.php');
}
?> 