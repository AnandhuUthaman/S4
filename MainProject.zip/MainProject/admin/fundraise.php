<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{


$status = $purposeErr = $descriptionErr = $client_nameErr = $end_dateErr = $fileToUploadErr = $expect_amountErr = $fileupload_status = "";
?>

<?php
if(isset($_POST['submit']))
{
     // Purpose Validation
     if(empty($_POST["purpose"]))
     {
         $purposeErr="Reqiured";
     }
     // Description Validation
     if(empty($_POST["description"]))
     {
        $descriptionErr="Reqiured";
     }
     // Client_name Validation
     if(empty($_POST["client_name"]))
     {
         $client_nameErr="Reqiured";
     }
     //end date validation
     if(empty($_POST["end_date"]))
     {
        $end_dateErr="Reqiured";
     } 
     //file upload validation
     if(empty($_POST["fileToUpload"]))
     {
 
          $fileToUploadErr="Required";
          $fileupload_status="File was not uploaded.";
 
     }
  //Amount field validation
  if(empty($_POST["amount"]))
  {
    $expect_amountErr="Reqiured";
  }


   $validdigit = "/(?=.*?[0-9])/";
   $validCharacters="/^[a-zA-Z ]*$/";
   $SpecialCharacters = "/(?=.*?[#?!@$%^&*-])/";

   $email=$_SESSION['email'];
   $title=$_POST['purpose'];
   $desc=$_POST['desc'];
   $client_name=$_POST['client_name'];
   $start_date=date("Y-m-d");
   $end_date=$_POST['end_date'];
   $amount=$_POST['expect_amount'];
 

//upload documents(pdf only)   
$filename = $_FILES["fileToUpload"]['name'];
$target_dir = "uploads/pdf/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$temp = explode(".", $_FILES["fileToUpload"]["name"]);
$extension = end($temp);
      
// Check if file already exists
if (file_exists($target_file)) {
  $fileupload_status="Sorry, file already exists.";
   $uploadOk = 0;
 }
 
 // Check file size
 if ($_FILES["fileToUpload"]["size"] > 500000) {
   $fileupload_status="Sorry, your file is too large.";
   $uploadOk = 0;
 }
 // Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
   $fileupload_status="Sorry, your file was not uploaded.";
 // if everything is ok, try to upload file
 } else {
   if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],"uploads/pdf/" . $_FILES["fileToUpload"]["name"])) {
     echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
   } else {
     $fileupload_status="Sorry, there was an error uploading your file.";
   }
 }
   
   if($amount == 0 || $amount < 0)
    {   
     echo'<script>alert("Enter valid number")</script>';
   }
     
      // Purpose Validation
	    if (!preg_match($validCharacters,$title)) {
		 echo '<script>alert("Digits are not allowed in purpose")</script>';
		 }
      // Description Validation
	    if (!preg_match($validCharacters,$desc)) {
		 echo '<script>alert("Digits are not allowed in description")</script>';
		 } 
       // client name Validation
      if(empty('$client_name'))
      {
           echo '<script>alert("client name field is required")</script>';
      }
      if (!preg_match($validCharacters,$client_name) || preg_match($SpecialCharacters,$client_name)) 
      {
           echo '<script>alert("Digits and special characters are not allowed in client name field")</script>';
      }
      if($amount > 100000)
      {
           echo '<script>alert("Amount less than 1 Lakh only allowed!")</script>';
      } 
             
      if($amount <= 100000 && preg_match($validCharacters,$title) && preg_match($validCharacters,$desc))
      {
            $sql="INSERT INTO `fundraise`(`email`, `client`, `purpose`, `desc`, `start_date`, `end_date`, `proof1`, `proof2`, `amount`) VALUES ('$email','$client_name','$title','$desc','$start_date','$end_date','$filename','$filename','$amount');";
            if(mysqli_query($con,$sql))
            {
                     $status = "Fund raised Successfully---!";
                     echo '<script>alert("Fund raised Successfully---!")</script>';
            }
            else
            {
                     echo '<script>alert("Failed")</script>';
            }
                 
      }
      else
      {     $status = "Failed to raise fund!";
            echo '<script>alert("Failed to raise fund!")</script>';
      }
        
    
  }  

?>



<!DOCTYPE html>
<html>
<head>
   <title>ChaitABLE | Admin |Raise Fund</title>
   <link rel="stylesheet" type="text/css" href="fundraise.css">
   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
      .error
      {
          color: red;
      }
   </style>
    <style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	   margin-top: 30px;
      margin-left: 280px;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
  </style>
</head>
<body>
<header>
     <label for="check">
      <i class="fas fa-bars" id="sidebtn"></i>
      <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
     </label>
   <div class="left">
      <h3>Charit<span>ABLE</span> </h3>
   </div>

   <div class="right" style="margin-top: 10px;">
      <form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn" style="margin-left:900px;">&#128274;Logout</button>
</form>
<a href="feedback.php" class="logoutbtn" style="margin-right: 150px;">&#9993;</a>
<a href="notifications.php" class="logoutbtn" style="margin-right:210px;">&#128276;</a>
      <!---<a href="logout.php" class="logoutbtn">Logout</a>------>
   </div>
</header>

<div class="sidebar">
<center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
</center>
    <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

  </div>
  <div class="table_responsive" style="margin-left: 370px;">
  <table>
                    
    <tbody>            
                    <form action="" method="POST" role="form" enctype="multipart/form-data">
                    <tr>
                        <td style="font-size:22px; padding-left:180px;">
                        Add Request to Collect Fund
                        </td>
                    </tr>
                     <tr>
                        <td style="color: black;">
                        Purpose&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value=""class="form-control mb-3" name="purpose" placeholder="Purpose" required><span class="error">* <?php echo $purposeErr; ?></span></td>
                    </tr>
                    <tr>
                        <td style="color: black;">Description&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="desc" placeholder="Description" required><span class="error">* <?php echo $descriptionErr; ?></span></td>
                    </tr>
                    <tr><td style="color: black;">
                        Client name&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value=""class="form-control mb-3" name="client_name" placeholder="Client name" required><span class="error">* <?php echo $client_nameErr; ?></span></td>
                    </tr>
                    <tr>
                        <td style="color: black;">End Date&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="date" value="" class="form-control mb-3" min="<?php echo (new DateTime())->format('Y-m-d') ?>" max="2022-12-31" name="end_date" placeholder="End Date" required><span class="error">* <?php echo $end_dateErr; ?></span></td>
                    </tr>
                    <tr>
                       <td style="color: black;">
                         Upload Document(PDF file only)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="fileToUpload" id="fileToUpload" accept="application/pdf" required/><span class="error"><?php echo $fileToUploadErr; ?></span></td>
                    </tr>
                    <tr>
                        <td style="color: black;">
                           Upload Document(PDF file only)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="proof2" id="proof2" accept="application/pdf" required/><span class="error"><?php echo $fileToUploadErr; ?></span></td>
                     </tr>
                     <tr>
                        <td style="color: black;">Expected Amount&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="number" value="" class="form-control mb-3" name="expect_amount" placeholder="Amount" min="10000" max="100000" required><span class="error">* <?php echo $expect_amountErr; ?></span></td>
                     </tr>
                     <tr>
                         <td><span class="error"><?php echo $fileupload_status; ?></span></td></tr></td>
                     </tr>
                     <tr>

                        <td><input type="submit" name="submit" class="action_btn" value="Submit"></td>
                     </tr>
                     <tr>
                     <td ><a href="viewFundRequest.php" style="text-decoration: none !important; color: blue; font-size:18px;">Raised Funds</a></td>
                     
                     <div id="box" class="snackbar"><?php echo $status; ?></div>
                     <script src="welcome.js"></script>
                     </tr>
                    </table>
   </form>
   </div>

  
</div>
</body>
</html>
<?php
}
else
{
    header('location: ../index.php');
}
?>