<?php
session_start();
$e=$_SESSION['email'];

$action = $_GET['action'];
$email = $_GET['email'];
//echo $action;
//echo $email;
include('config.php');

$sql="UPDATE registration SET approval='$action' where email='$email'";
$res=mysqli_query($con,$sql);
// if($res)
// {
//     echo "success...";
// }
// else
// {
//     echo "failed...";
// }
Header("Location: registrationApproval.php");

?>