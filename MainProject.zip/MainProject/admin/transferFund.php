<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{


?>
<!DOCTYPE html>
<html>
<head>
	<title>ChaitABLE | Admin |Fund Transaction</title>
	<link rel="stylesheet" type="text/css" href="transferFund.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
         <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>

	<div class="right" style="margin-top: 10px;">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn" style="margin-left: 900px;">&#128274;Logout</button>
</form>
<a href="feedback.php" class="logoutbtn" style="margin-right: 150px;">&#9993;</a>
<a href="notifications.php" class="logoutbtn" style="margin-right:210px;">&#128276;</a>
		
	</div>
</header>
 
  <div class="sidebar">
  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
      </center>
    <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>
  </div>
  <div class="table_responsive" style="margin-left: 370px;">
  <table>
                    
                    <!----<input type="hidden" name="cod_estudiante" value="<?php echo $row['cod_estudiante']  ?>">---->
    <tbody>            
                    <form action="checkAccDetails.php" method="POST">
                        
                    <tr>
                        <td>First name&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="fname" placeholder="Client First name"></td>
                    </tr>
                    <tr><td>
                        Last name&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value=""class="form-control mb-3" name="lname" placeholder="Client Last name"></td>
                    </tr>
                    
                    
                <tr>
                    <td><input type="submit" name="submit" class="btn btn-primary btn-block" value="check"></td></tr>
                    </form>
       <tbody></table>
    </div>    
  <!---<div class="content"></div>-->
</body>
</html>
<?php
}
else
{
    header('location: ../index.php');
}
?>