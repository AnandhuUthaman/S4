<?php
session_start();
$email=$_SESSION['email'];
//if(isset($_POST['submit']))
//{
    //include('config.php');
//if(isset($_POST['fname']) && trim($_POST['fname']) != "" && isset($_POST['email']) && trim($_POST['email']) != "")

//{
if(isset($_SESSION['email'])) 
{
   
     include('config.php');
     
     $email4a=$_GET['id'];


   $sql="UPDATE registration SET block=1 where email='$email4a'";
   $res=mysqli_query($con,$sql);
   if($res)
   {
        echo '<script>alert("Account Blocked")</script>';

        Header("Location: ./accounts.php");
   }
   else
   {
        echo '<script>alert("Failed to block")</script>';
   }
   Header("Location: ./accounts.php");
  //}
}
?>