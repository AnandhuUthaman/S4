<?php
session_start();
$email = $_SESSION['email'];

include('config.php');

        $sql="UPDATE fundraise SET action='accepted' where email='$email'";
        mysqli_query($con,$sql);
        header('Location: fundrequests.php')
?>