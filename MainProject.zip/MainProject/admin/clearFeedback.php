<?php
session_start();
$email=$_SESSION['email'];

include('config.php');
$id=$_GET['id'];

if(isset($_SESSION['email']))
{
    $sql="DELETE from contact where id='$id'";
    mysqli_query($con,$sql);
    header('Location: feedback.php');
}
else
{
    header('location: ../index.php');
}
?>