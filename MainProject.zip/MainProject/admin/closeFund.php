<?php
session_start();
$email=$_SESSION['email'];

include("config.php");

$id = $_GET['id'];
//echo "$email";
$status = "closed";

if(isset($_SESSION['email']))
{


    $sql = "UPDATE `fundraise` SET `scope`='closed' WHERE `id`='$id';";
    $res=mysqli_query($con,$sql);

    if ($res) 
    {
?>
    <script>
        alert("closed");
        window.location = "./raisedfunds.php";
    </script>
<?php
}   else 
    {
?>
    <script>
        alert("Failed")
    </script>;
<?php
    }
}
else
{
    header('location: ../index.php');
}    
?>