<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{


?>
<!DOCTYPE html>
<html>
<head>
	<title>ChaitABLE | Admin |Profile</title>
	<link rel="stylesheet" type="text/css" href="profile.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
		 <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>
	
	<div class="right">
		<form action="logout.php" method="POST"> 
             <button type="submit" name="logout" class="logoutbtn">&#128274;Logout</button>
        </form>
        <a href="feedback.php" class="logoutbtn">&#9993;</a>
        <a href="notifications.php" class="logoutbtn" style="margin-right:100px;">&#128276;</a>
	</div>
	<!--<h2 style="margin-left: 300px; width: 800px; height: 30px; background-color:rgb(209, 18, 18); text-align: center;">&nbspAdmin Panel</h2>--->
</header>
 
  <div class="sidebar">
  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
   <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

  </div>


<div class="container" style="margin-left:330px; padding-top: 90px">
 <table>
 <tr>
    <td class="left" style="background-color:whitesmoke; color:black;">
<section>
<label for="fileToUpload">
<i class="fa fa-camera"></i>
<input type="file" id="fileToUpload" style="visibility:hidden;" accept=".png,.jpg,jpeg,.PNG,.JPEG" name="fileToUpload" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
</label>
<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" id="blah" alt="Avatar"> 
</section>

  		<h1><?php echo $row['fname'];?></h1>
  		   
<h3>Administrator</h3>
</td>
<td style=" background-color:whitesmoke; color:black;">
<ul style="margin-top:30px;">
<form action="" method="POST">
<li style="color:black;"><b>First name</b> <input type="text" name="fname" id="fname" maxlength="100" value="<?php echo $row['fname'];?>" required /> <i class="fa fa-edit" id="edit1" onclick="document.getElementById('fname').style.pointerEvents='auto';document.getElementById('fname').focus();this.style.display='none'; document.getElementById('check1').style.display='inline-block';"></i> <i class="fa fa-check" style="display:none;" id="check1" onclick="document.getElementById('edit1').style.display='inline-block';this.style.display='none';document.getElementById('fname').style.pointerEvents='none';"></i></li>
<li style="color:black;"><b>Last name</b> <input type="text" name="lname" id="lname" maxlength="100" value="<?php echo $row['lname'];?>" required /> <i class="fa fa-edit" id="edit2" onclick="document.getElementById('lname').style.pointerEvents='auto';document.getElementById('lname').focus();this.style.display='none'; document.getElementById('check2').style.display='inline-block';"></i> <i class="fa fa-check" style="display:none;" id="check2" onclick="document.getElementById('edit2').style.display='inline-block';this.style.display='none';document.getElementById('lname').style.pointerEvents='none';"></i></li>
<li style="color:black;"><b>Email</b> <?php echo $row['email'];?></li>
<li style="color:black;"><b>Contact number</b> <input type="text" name="phno" id="phno" maxlength="100" value="<?php echo $row['phno'];?>" required /> <i class="fa fa-edit" id="edit3" onclick="document.getElementById('phno').style.pointerEvents='auto';document.getElementById('phno').focus();this.style.display='none'; document.getElementById('check3').style.display='inline-block';"></i> <i class="fa fa-check" style="display:none;" id="check3" onclick="document.getElementById('edit3').style.display='inline-block';this.style.display='none';document.getElementById('phno').style.pointerEvents='none';"></i></li>
<li style="color:black;"><b>Address</b> <input type="text" name="hname" id="hname" maxlength="100" value="<?php echo $row['hname'];?>" required /> <i class="fa fa-edit" id="edit4" onclick="document.getElementById('hname').style.pointerEvents='auto';document.getElementById('hname').focus();this.style.display='none'; document.getElementById('check4').style.display='inline-block';"></i> <i class="fa fa-check" style="display:none;" id="check4" onclick="document.getElementById('edit4').style.display='inline-block';this.style.display='none';document.getElementById('hname').style.pointerEvents='none';"></i></li>
<li style="color:black;"><b>Place</b> <input type="text" name="place" id="place" maxlength="100" value="<?php echo $row['place'];?>" required /> <i class="fa fa-edit" id="edit5" onclick="document.getElementById('place').style.pointerEvents='auto';document.getElementById('place').focus();this.style.display='none'; document.getElementById('check5').style.display='inline-block';"></i> <i class="fa fa-check" style="display:none;" id="check5" onclick="document.getElementById('edit5').style.display='inline-block';this.style.display='none';document.getElementById('place').style.pointerEvents='none';"></i></li>
<li style="color:black;"><b>District</b> <input type="text" name="dist" id="dist" maxlength="100" value="<?php echo $row['dist'];?>" required /> <i class="fa fa-edit" id="edit6" onclick="document.getElementById('dist').style.pointerEvents='auto';document.getElementById('dist').focus();this.style.display='none'; document.getElementById('check6').style.display='inline-block';"></i> <i class="fa fa-check" style="display:none;" id="check6" onclick="document.getElementById('edit6').style.display='inline-block';this.style.display='none';document.getElementById('dist').style.pointerEvents='none';"></i></li>
<li><b><a href="changePsw.php">Change password</a></li>
<li><a href="editProfile.php">Edit details</a></li>
</form>
</ul>
</td>
</tr>

<?php
		}
?>

</table>
</div>


<!--JAVASCRIPT-->
<script src="js/custom.js"></script>
<script>
function editdetails2(){
}

var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
  close[i].onclick = function(){
    var div = this.parentElement;
    div.style.opacity = "0";
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
</body>
</html>
<?php
}
else
{
    header('location: ../index.php');
}
?>