<?php
session_start();
$email=$_SESSION['email'];

include('config.php');
if(isset($_SESSION['email']))
{
    $sql="TRUNCATE TABLE contact";
    mysqli_query($con,$sql);
    header('Location: feedback.php');
}
else
{
   header('location: ../index.php');
}
?>