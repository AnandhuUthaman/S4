<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
</head>
<body>
    <form action="pay.php" method="post">
        Price: <input type="text" name="price"><br>
        Name: <input type="text" name="customername"><br>
        Email: <input type="email" name="email"><br>
        Contact No: <input type="text" name="contactno"><br>
        <input type="submit" name="submit" value="Proceed To Pay">
</form>
</body>
</html>