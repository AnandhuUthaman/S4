<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{

    $about_fnErr = $fn_dateErr = $fund_givenErr = $client_nameErr = $org_nameErr = $event_typeErr= $imageUploadErr = $Err_message = "";
    
    if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit']))
    {
    
       $validDigits = "/(?=.*?[0-9])/";
       $validCharacters="/^[a-zA-Z ]*$/";
       $specialCharacters = "/(?=.*?[#?!@$%^&*-])/";
    
       function test_input($data)
       {
         
         $data = trim($data);
         $data = stripslashes($data);
         $data = htmlspecialchars($data);
         
         return $data;
       }
    

       $about_fn=test_input($_POST['about_fn']);
       $fn_date=$_POST['date'];
       $fund_given=test_input($_POST['fund_given']);
       $client_name=test_input($_POST['client_name']);
       $org_name=test_input($_POST['org_name']);
       $event_type=test_input($_POST['event']);



       if(isset($_POST['submit']))
       {
              $filename = $_FILES["imageUpload"]['name'];
              $tempname = $_FILES["imageUpload"]["tmp_name"];    
              move_uploaded_file($tempname,"images/".$filename);
       }



// Description Validation
if(empty($about_fn))
{
    $about_fnErr = "Description is Required";
}
if (!preg_match($validCharacters,$about_fn)) 
{
    $about_fnErr = "Digits are not allowed in Description";
} 
if (preg_match($specialCharacters,$about_fn)) 
{
    $about_fnErr = "Special characters are not allowed in Description";
}
//  Date of Function Validation
if(empty($fn_date))
{
    $fn_dateErr = "Date is Required";
}
// Fund given Validation
if(empty($fund_given))
{
    $fund_givenErr = "Fund given is Required";
}
if (!preg_match($validDigits,$fund_given)) 
{
    $fund_givenErr = "Characters are not allowed in Fund given";
} 
if (preg_match($specialCharacters,$fund_given)) 
{
    $fund_givenErr = "Special characters are not allowed in Fund given";
}
// Client name Validation
if(empty($client_name))
{
    $client_nameErr = "Client name is Required";
}
if (!preg_match($validCharacters,$client_name)) 
{
    $client_nameErr = "Digits are not allowed in Client name";
} 
if (preg_match($specialCharacters,$client_name)) 
{
    $client_nameErr = "Special characters are not allowed in Client name";
}
// Organization/Institute name Validation
if(empty($org_name))
{
    $org_nameErr = "Organization/Institute name is Required";
}
if (!preg_match($validCharacters,$org_name)) 
{
    $org_nameErr = "Digits are not allowed in Organization/Institute name";
} 
if (preg_match($specialCharacters,$org_name)) 
{
    $org_nameErr = "Special characters are not allowed in Organization/Institute name";
}
// Event type Validation
if(empty($event_type))
{
    $event_typeErr = "Event type is Required";
}
      
    
          if(!empty('$about_fn') && preg_match($validCharacters,$about_fn) && !empty('$fn_date') && !empty('$fund_given') && preg_match($validDigits,$fund_given) && !empty('$client_name') && preg_match($validCharacters,$client_name) && !empty('$org_name') && preg_match($validCharacters,$org_name) && !empty('$eventtype'))
          {
    
    
              $sql="INSERT INTO `offline_activity`(`about_fn`, `fund_given`, `client_name`, `org_name`, `date`, `fn_images`, `event_type`) VALUES ('$about_fn','$fund_given','$client_name','$org_name','$fn_date','$filename','$event_type')";
              $res=mysqli_query($con,$sql);
              if($res)
              {
                    echo '<script>alert("Added")</script>';
    
              }
              else
              {
                    echo '<script>alert("Failed")</script>';
              }
          }
          else
          {
               
          }
    }
    
?>
<!DOCTYPE html>
<html>
<head>
	<title>ChaitABLE | Admin |Achievements</title>
	<link rel="stylesheet" type="text/css" href="addAchieves.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<style>
.error
{
    color: red;
    font-size: 17px;
}
</style>
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
         <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>

	<div class="right" style="margin-top: 10px;">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn" style="margin-left: 900px;">&#128274;Logout</button>
</form>
<a href="feedback.php" class="logoutbtn" style="margin-right: 150px;">&#9993;</a>
<a href="#" class="logoutbtn" style="margin-right:210px;">&#128276;</a>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</header>
 
  <div class="sidebar">
  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
      <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

  </div>
  <div class="table_responsive" style="margin-left: 370px;">
  <table style="margin-top: 120px;">
                    
                   
    <tbody>            
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <tr>
                        <td style="font-size:22px; padding-left:180px;">
                        Add Offline Activities
                        </td>
                    </tr>
                    <tr>
                        <td>Description&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="about_fn" placeholder="About function" required></td>
                    </tr>
                    <div class="error"><span><?php echo $about_fnErr; ?></span></div>
                    <tr>
                        <td>Function Date&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="date" value="" class="form-control mb-3" name="date" placeholder="Function conducted Date" required></td>
                    </tr>
                    <div class="error"><span><?php echo $fn_dateErr; ?></span></div> 
                    <tr>
                        <td>Fund given&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value=""class="form-control mb-3" name="fund_given" placeholder="Amount given" required></td>
                    </tr>
                    <div class="error"><span><?php echo $fund_givenErr; ?></span></div> 
                    <tr>
                        <td>Client name&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="client_name" placeholder="client name" required></td>
                    </tr>
                    <div class="error"><span><?php echo $client_nameErr; ?></span></div>
                    <tr>
                        <td>Organization/Institution name&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="org_name" placeholder="Organization/Institution" required></td>
                    </tr>
                    <div class="error"><span><?php echo $org_nameErr; ?></span></div>
                    <tr>
                        <td>Event Type&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>

                            <td><select id="event" name="event" required>   
                                <option name="eventtype" value="none" selected disabled hidden>Select Event Type</option> 
                                <option name="Frequent Distribution">Frequent Distribution</option>
                                <option name="Dicease">Dicease</option>
                                <option name="Disaster">Disaster</option>
                            </td> 
                    </tr>
                    <div class="error"><span><?php echo $event_typeErr; ?></span></div>
                    <tr>
                        <td> Upload Images<input type="file" name="imageUpload" id="imageUpload" required></td>
                    </tr>
                    <div class="error"><span><?php echo $imageUploadErr; ?></span></div>
                    <tr>
                        <td><input type="submit" name="submit" class="btn btn-primary btn-block" value="Add"></td>
                    </tr>
                    </form>
       <tbody></table>
    </div>    
</body>
</html>
<?php
}
else
{
    header('location: ../index.php');
}
?>