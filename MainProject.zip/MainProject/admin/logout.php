<?php
session_start();
$e=$_SESSION['email'];
include('config.php');

   if(isset($_SESSION['email']) && isset($_POST['logout']))
   {

     $sql="delete from login where utype='user' AND email='$e'";
     mysqli_query($con,$sql);

       session_destroy();
       unset($_SESSION['email']);
       header('location:../index.php');

   }
?>
<!DOCTYPE html>
<html>
<head>
  <!-- <SCRIPT type="text/javascript" language="javascript">
    window.history.forward();
    function noBack() 
    {

     window.history.forward();
    }
</SCRIPT>   -->
<script>
  function preventBack()
  {
    window.history.forward();
  }  
  setTimeout("preventBack()", 10000);
  window.onunload = function () { null };
  function Redirect()
  {
    window.location = "index.php";
  }
</script>
</head>
<body onload="preventBack();" onpageshow="if (event.persisted) preventBack();" onunload="Redirect();">
</body>
</html>