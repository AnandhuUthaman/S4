<?php
session_start();
$email=$_SESSION['email'];
if(isset($_SESSION['email']) && isset($_POST['submit']))
{

include('config.php');

$fname=$_POST['fname'];
$lname=$_POST['lname'];
//echo $fname;
//echo $lname;


   $sql="SELECT * from clientaccount ca,registration re where ca.client_id=re.id and re.fname='$fname'";
   $res=mysqli_query($con,$sql);
   if(mysqli_fetch_array($res))
    {
    header('Location: accDetails.php');

    }
    else
    {
        echo '<script>alert("No such account named $fname")</script>';
    header('Location: transferFund.php');
    
   }
}
else
{
    header('location: ../index.php');
}
?>