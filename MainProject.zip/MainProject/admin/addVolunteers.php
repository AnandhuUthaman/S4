<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{


?>
<!DOCTYPE html>
<html>
<head>
	<title>ChaitABLE | Admin | Request Volunteers</title>
	<link rel="stylesheet" type="text/css" href="addVolunteers.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
         <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>

	<div class="right" style="margin-top: 10px;">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn" style="margin-left: 900px;">&#128274;Logout</button>
</form>
<a href="feedback.php" class="logoutbtn" style="margin-right: 150px;">&#9993;</a>
<a href="#" class="logoutbtn" style="margin-right:210px;">&#128276;</a>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</header>
 
  <div class="sidebar">
  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
      </center>
    <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>
  </div>
  <div class="table_responsive" style="margin-left: 370px;">
  <table>
                    
                    <!----<input type="hidden" name="cod_estudiante" value="<?php echo $row['cod_estudiante']  ?>">---->
    <tbody>            
                    <form action="" method="POST">
                    <tr>
                        <td style="font-size:22px; padding-left:150px;">
                        Add Request For Volunteering
                        </td>
                    </tr>
                    <tr>
                        <td style="padding-left:40px;">Event Id &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbspl&nbsp;&nbsp;&nbsp;&nbsp;
                          <select id="dopt" name="dopt" required>   
                          <option name="district" value="none" selected disabled hidden required>Select Id</option> 
                          <!-- <option name="Kottayam">Kottayam</option>
                          <option name="Idukki">Idukki</option>
                          <option name="Kollam">Kollam</option>
                          <option name="Alappuzha">Alapuzha</option>
                          <option name="Trivandrum">Trivandrum</option>
                          <option name="Ernakulam">Ernakulam</option>
                          <option name="Pathanamthitta">Pathanamthitta</option>
                          <option name="Thrissur">Thrissur</option>
                          <option name="Palakkad">Palakkad</option>
                          <option name="Kozhikkode">Kozhikkod</option>
                          <option name="Kannur">Kannur</option>
                          <option name="Wayanad">Wayanad</option>
                          <option name="Malappuram">Malappuram</option>
                          <option name="Kasargod">Kasargod</option> -->
                          </select>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding-left:40px;">Role of Volunteers&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="desc" placeholder="Description" required></td>
                    </tr>
                    <tr>
                        <td style="padding-left:40px;">
                        Total Volunteers needed&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value=""class="form-control mb-3" name="client_name" placeholder="Client name" required></td>
                    </tr>
                    <tr>
                        <td style="padding-left:40px;">
                        Add reserved List&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value=""class="form-control mb-3" name="center" placeholder="Center" required></td>
                    </tr>
                    <tr>
                        <td style="padding-left:40px;">
                        End Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="date" value="" class="form-control mb-3" name="end_date" placeholder="End Date" required></td>
                    </tr>
                    <tr>
                        <td style="padding-left:40px;">
                        Reporting Time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" value="" class="form-control mb-3" name="place" placeholder="Place" required></td>
                    </tr>
                   
                    <!-- <tr>
                        <td style="padding-left:40px;">
                        Food and Travel charge&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="expect_amount" placeholder="Amount" required></td>
                    </tr> -->
                    <td style="padding-left:40px;">Event Type
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <select id="event" name="event" required>   
  <option name="eventtype" value="none" selected disabled hidden>Select Event Type</option> 
  <option name="Frequent Distribution">Frequent Distribution</option>
  <option name="Dicease">Dicease</option>
  <option name="Disaster">Disaster</option>
                    </tr>
                <tr>
                    <td><input type="submit" name="submit" class="" style="margin-left: 40px;" value="Create"></td>
                </tr>
                <tr>
                    <td><a href="" style="text-decoration:none !important; font-size:18px; color: blue; margin-left: 40px;">Scheduled list</a></td>
                </tr>
                    </form>
       <tbody></table>
    </div>    
</body>
</html>
<?php

if(isset($_POST['submit']))
{

include('config.php');

$purpose=$_POST['purpose'];
$description=$_POST['desc'];
$client_name=$_POST['client_name'];
$org_name=$_POST['org_name'];
$start_date=date("Y-m-d");
$end_date=$_POST['end_date'];
$center=$_POST['center'];
$place=$_POST['place'];
$district=$_POST['dopt'];
$expect_amount=$_POST['expect_amount'];
$event_type=$_POST['event'];

   $validDigits = "/(?=.*?[0-9])/";
   $validCharacters="/^[a-zA-Z ]*$/";
   $SpecialCharacters = "/(?=.*?[#?!@$%^&*-])/";

// Purpose Validation
if(empty('$purpose')){
    echo '<script>alert("Purpose field is required")</script>';
}
if (!preg_match($validCharacters,$purpose) || preg_match($SpecialCharacters,$purpose)) {
    echo '<script>alert("Digits and special characters are not allowed in purpose field")</script>';
    }
 // Description Validation
 if(empty('$description')){
    echo '<script>alert("Description field is required")</script>';
}
   if (!preg_match($validCharacters,$description) || preg_match($SpecialCharacters,$description)) {
    echo '<script>alert("Digits and special characters are not allowed in description field")</script>';
    } 
    // Client name Validation
    if(empty('$client_name')){
        echo '<script>alert("Client name field is required")</script>';
    }
if (!preg_match($validCharacters,$client_name) || preg_match($SpecialCharacters,$client_name)) {
    echo '<script>alert("Digits and special characters are not allowed in Client name field")</script>';
    }
 // Organization Validation
 if(empty('$org_name')){
    echo '<script>alert("Organization/Institution field is required")</script>';
}
   if (!preg_match($validCharacters,$org_name) || preg_match($SpecialCharacters,$org_name)) {
    echo '<script>alert("Digits and special characters are not allowed in Organization/Institution field")</script>';
    } 
    // center Validation
    if(empty('$center')){
        echo '<script>alert("Center field is required")</script>';
    }
if (!preg_match($validCharacters,$center) || preg_match($SpecialCharacters,$center)) {
    echo '<script>alert("Digits and special characters are not allowed in center field")</script>';
    }
 // Place Validation
 if(empty('$place')){
    echo '<script>alert("Place field is required")</script>';
}
   if (!preg_match($validCharacters,$place) || preg_match($SpecialCharacters,$place)) {
    echo '<script>alert("Digits and special characters are not allowed in place field")</script>';
    } 
    // End date Validation
    if(empty('$end_date')){
        echo '<script>alert("End date field is required")</script>';
    }
    // District Validation
 if(empty('$district')){
    echo '<script>alert("District field is required")</script>';
}
    // Amount Validation
 if(empty('$expect_amount')){
    echo '<script>alert("Amount field is required")</script>';
}
   if (!preg_match($validDigits,$expect_amount)) {
    echo '<script>alert("Characters are not allowed in Amount field")</script>';
    } 
    // Event type Validation
 if(empty('$event_type')){
    echo '<script>alert("Event type field is required")</script>';
}
  if($expect_amount > 100000){
    echo '<script>alert("Amount less than 1 Lakh only allowed!")</script>';
   } 
   if (preg_match($validCharacters,$purpose) && preg_match($validCharacters,$description) && preg_match($validCharacters,$client_name) && preg_match($validCharacters,$org_name) && preg_match($validCharacters,$center) && preg_match($validCharacters,$place)) 
   {
        if($expect_amount <= 100000)
        {
                 $sql="INSERT into events (purpose,description, client_name,org_name,start_date,end_date,dist_center,place,district,expect_amount,event_type)values('$purpose','$description','$client_name','$org_name','$start_date','$end_date','$center','$place','$district','$expect_amount','$event_type')";
                 $res=mysqli_query($con,$sql);
                 if($res)
                 {
                      echo '<script>alert("Added")</script>';

                }
                    
                else
                {
                      echo '<script>alert("Failed")</script>';
                }
        }
        
   }
}

?>
<?php
}
else
{
    header('location: ../index.php');
}
?>