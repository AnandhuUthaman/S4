<?php
session_start();
$e=$_SESSION['email'];

include("config.php");

     $email=$_GET['id'];
     //echo "$email";
if(isset($_SESSION['email']))
{


     $sql="UPDATE `registration` SET `active`=1 WHERE `email`='$email'";
     $query=mysqli_query($con,$sql);

    if($query)
    {
        echo '<script>alert("deleted")</script>';
        
        Header("Location: manageAccounts.php");
    }
    else
    {
        echo '<script>alert("Failed")</script>';
    }
}
else
{
    header('location: ../index.php');
}
?>