<?php

session_start();
if (isset($_SESSION['email'])) 
{ 
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>ChaitABLE | Admin|Approve Fund</title>
	<link rel="stylesheet" type="text/css" href="fundApproval.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
		 <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>
	
	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">&#128274;Logout</button>
</form>

		 <a href="feedback.php" class="logoutbtn">&#9993;</a>
		 <a href="notifications.php" class="logoutbtn" style="margin-right:100px;">&#128276;</a>
	
	</div>
	<!--<h2 style="margin-left: 300px; width: 800px; height: 30px; background-color:rgb(209, 18, 18); text-align: center;">&nbspAdmin Panel</h2>--->
</header>
 
  <div class="sidebar">
  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
   <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

  </div>

  <nav>
         <label for="btn" class="button">User credentials
         <span>&#128194;</span>
         </label>
         <input type="checkbox" id="btn">
         <ul class="menu">
            <li><a href="fundApproval.php">Fund approval</a></li>
            <li>
               <label for="btn-2" class="first"><a href="registrationApproval.php">A/C approval</a>
               </label>
               
            </li>
            <li>
               <label for="btn-3" class="second"><a href="issues.php">Issues</a>
               </label>
               
            </li>
            <li><a href="messages.php">Contact</a></li>
            <li><a href="feedback.php">Feedback</a></li>
         </ul>
      </nav>
      <!-- This code used to rotate drop icon(-180deg).. -->
      <script>
         $('nav .button').click(function(){
           $('nav .button span').toggleClass("rotate");
         });
           $('nav ul li .first').click(function(){
             $('nav ul li .first span').toggleClass("rotate");
           });
           $('nav ul li .second').click(function(){
             $('nav ul li .second span').toggleClass("rotate");
           });
      </script>

<!-- <div class="content" style="width: 1000px; background: black; margin-top:90px;">
         <a href="fundrequests.php" class="btn_funds">Processing</a>
         <a href="raisedfunds.php" class="btn_funds" style="background-color:blue; color:white;">Donated</a>
         <a href="closedRequests.php" class="btn_funds">Closed</a>
        <h2 style="margin-left:420px; font-weight:25px;">Donated Funds</h2>
</div> -->

   <div class="table_responsive">
   <h2 style="margin-top:90px; margin-left:260px; font-weight:25px;">Approve Fund Requests</h2>
    <table>
      <thead>
        <tr>
          <th>Purpose</th>
          <th>Description</th>
          <th>Aadhar number</th>
          <th>Phone</th>
          <th>Place</th>
          <th>District</th>
          <th>Approval</th>
         
        </tr>
      </thead>

      <tbody>
         
               
               <?php
                  
                  include('config.php');

                  //Taking value from table registration
                  $query="SELECT * from fundraise join events";
                  $ch=mysqli_query($con,$query);
                //   $row1=mysqli_fetch_assoc($ch);
                //   if($row1=="")
                //   {
                //     echo "no new entry.....";
                //   }
                  while($row1=mysqli_fetch_assoc($ch))
                  {                 
               ?>
                <tr>
                    <td><?php echo $row1['purpose'] ?></td>
                    <td><?php echo $row1['desc'] ?></td>
                    <td><?php echo $row1['aadhar'] ?></td>
                    <td><?php echo $row1['phno'] ?></td>
                    <td><?php echo $row1['place'] ?></td>
                    <td><?php echo $row1['dist'] ?></td>
                        <td>
                            <button class="but1"><a href="regApprove.php?action=approved&email=<?php echo $row1['email'];?>">Approve</a>
                            <button class="but1" style="margin-left:15px;"><a href="regApprove.php?action=rejected&email=<?php echo $row1['email'];?>">Reject</a>
                        </td>
                </tr>           
               <?php         
                   }
               ?>  
                 
      </tbody>
    </table>
    
</div>


</body>
</html>
<?php
    }
 else
 {
       header('location: ../index.php');
 }
?>
