<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{


?>
<html>
<head>
   <title>ChaitABLE | Admin |Processing Requests</title>
   <link rel="stylesheet" type="text/css" href="viewFundRequest.css">
   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<header>
     <label for="check">
      <i class="fas fa-bars" id="sidebtn"></i>
      <a href="home.php" class="logoutbtn" style="margin-right: 900px; margin-top: 0px;">&#127968;</a>
     </label>
   <div class="left">
      <h3>Charit<span>ABLE</span> </h3>
   </div>

   <div class="right">
      <form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">&#128274;Logout</button>
</form>
<a href="feedback.php" class="logoutbtn" style="margin-right: 150px;">&#9993;</a>
<a href="notifications.php" class="logoutbtn" style="margin-right:210px;">&#128276;</a>
   
   </div>
</header>


<div class="sidebar">
<center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
    </center>
    <a href="home.php"><i class="fas fa-desktop"></i> <span>Dashboard</span> </a>
   <a href="profile.php"> <i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="fundraise.php"><i class="fas fa-comment-dollar"></i> <span>Raise fund</span> </a>
   <a href="createEvents.php"><i class="fas fa-calendar"></i> <span>Create Event</span> </a>
   <a href="raisedfunds.php"> <i class="fas fa-donate"></i><span>Donations</span> </a>
   <a href="accounts.php"><i class="fas fa-address-book"></i> <span>Accounts</span> </a>
   <a href="addVolunteers.php"> <i class="far fa-envelope"></i><span>Request volunteering</span> </a>
   <a href="addAchieves.php"> <i class="fas fa-sliders-h"></i><span>Services</span> </a>
   <a href="accDetails.php"> <i class="fas fa-credit-card" area-hidden="true"></i><span>Transfer fund</span> </a>

  </div>

  <div class="content" style="width: 1000px;">
    <!-- <a href="fundrequests.php" class="btn_funds" style="background-color:blue; color:white;">Processing</a>
    <a href="raisedfunds.php" class="btn_funds">Donated</a>
    <a href="closedRequests.php" class="btn_funds">Closed</a> -->
    <h2 style="margin-left: 395px; font-weight: 25px;">Processing&nbsp;&nbsp;Requests</h2>
  </div>

   <div class="table_responsive">
    <table>
      <thead>
        <tr>
          <th>Client</th>
          <th>Purpose</th>
          <th>Description</th>
          <th>Requested Amount</th>
          <th>Collected</th>
          <th>End date</th>
          <th>Close Application</th>

        </tr>
      </thead>

      <tbody>
         
               
               <?php
                  
                  include('config.php');

                  //To check end_date reached or not. If reached, set scope=closed.
                  $end=date("Y-m-d");
                  echo $end;/* 
                  if($row['end_date'] <= $end)
                  {
                        $ins="UPDATE fundraise SET scope='closed' where end_date <= $end";
                        mysqli_query($con,$ins);                      
   
                  } */


                  //$sql="SELECT * from fundraise";
                   $sql="SELECT *,sum(famount) from fundraise, fundgiven where fundraise.id=fundgiven.fundid; ";
                  
                  $sq=mysqli_query($con,$sql);
                  while($row=mysqli_fetch_assoc($sq))
                  {                 
                  
               ?>
               <tr>
               <td ><?php echo $row['client'] ?></td>
               <td ><?php echo $row['purpose'] ?></td>
               <td ><?php echo $row['desc'] ?></td>
               <td >&#8377;<?php echo $row['amount'] ?></td>
               <td >&#8377;<?php echo $row['sum(famount)'] ?></td>
               <td><?php echo $row['end_date'] ?></td>
               <td>
               <!-- To check end_date reached or not. If not reached, admin can close it. -->
               <?php   
                  $end=date("Y-m-d");
                  if($row['end_date'] <= $end)
                  {
               ?>     
                       <button><a href="#">Close</a></button>                  
               <?php
                  }
                  else
                  {
                    echo "closed";
                  }  
              ?>                   
              </td>   
               <!-- <td><?php echo $row['approval'] ?></td> -->
               </tr>
               
               <?php
                  }
               ?>    
      </tbody>
    </table>

  </div>
</div>

</body>
</html>
<?php
}
else
{
    header('location: ../index.php');
}
?>