<?php
session_start();
include('config.php');

if (isset($_POST['submit'])) 
{


       $email = $_POST['email'];
       $psw = $_POST['psw'];
       $encrypted_pwd = md5($psw);
       $_SESSION['email'] = $email;
       $_SESSION['psw'] = $psw;


       $sql = "SELECT * FROM `registration` WHERE email='$email' and psw='$psw'";
       $sql1 = "SELECT * FROM `login` WHERE email='$email' and psw='$psw'";
       $re = mysqli_query($con, $sql);
       $re1 = mysqli_query($con, $sql1);
       if ($row = mysqli_fetch_array($re)) 
       {

              if (!empty($row)) 
              {
                     if ($row['role'] == "Admin") 
                     {
                            $_SESSION["id"] = $id;
                            $_SESSION["charitymain"] = session_id();
                            header('Location: admin/home.php');
                     }
                     if ($row['block'] == '1') 
                     {
                            //blocked accounts
                            header('Location: index.php');
                     } 
                     else 
                     {

                            if (mysqli_num_rows($re1) == 0) 
                            {

                                   if ($row['utype'] != "admin") 
                                   {
                                          $sql2 = "INSERT INTO `login`(`email`, `psw`) VALUES ('$email','$psw')";
                                          mysqli_query($con, $sql2);


                                          if ($row['role'] == "Donor") 
                                          {
                                                 if ($row['approval'] == 0) 
                                                 {
                                                        echo '<script>alert("Pending of approval of registration")</script>';
                                                       
                                                 }  

                                                 $_SESSION["id"] = $id;
                                                 $_SESSION["charitymain"] = session_id();

                                                 header('Location: donor/home.php');
                                          } 
                                          else if ($row['role'] == "Client") 
                                          {
                                                 if ($row['approval'] == 0) 
                                                 {
                                                        echo '<script>alert("Pending of approval of registration")</script>';
                                                       
                                                 } 
                                                 $_SESSION["id"] = $id;
                                                 $_SESSION["charitymain"] = session_id();

                                                 header('Location: client/home.php');
                                          } 
                                          else if ($row['role'] == "Volunteer")
                                           {
                                                 if ($row['approval'] == 0) 
                                                 {
                                                        echo '<script>alert("Pending of approval of registration")</script>';
                                                       
                                                 } 
                                                 $_SESSION["id"] = $id;
                                                 $_SESSION["charitymain"] = session_id();

                                                 header('Location: volunteer/home.php');
                                          }
                                   }
                            } else {
                                   echo '<script>alert("!----You are already logged in.Log out first----!")</script>';
                                   $sql3 = "delete from login where email='$email'";
                                   $del = mysqli_query($con, $sql3);
                            }
                     }
              }
              else
              {
                     header("Location:login.php?error=Invalid Email id/Password!!");
                     echo '<script>alert("Restricted")</script>';
              }
       } 
       else 
       {
              // header("Location:login.php?error=Invalid Email id/Password!!"); 
              echo '<script>alert("Restricted")</script>';
       }
}
?>