<?php
//session_start();
include('config.php');
if(isset($_POST['submit']))
{
//input fields are Validated with regular expression
$validName="/^[a-zA-Z ]*$/";
$validEmail="/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/";
$uppercasePassword = "/(?=.*?[A-Z])/";
$lowercasePassword = "/(?=.*?[a-z])/";
$digitPassword = "/(?=.*?[0-9])/";
$spacesPassword = "/^$|\s+/";
$symbolPassword = "/(?=.*?[#?!@$%^&*-])/";
$minEightPassword = "/.{8,}/";

//  First Name Validation
if(empty($fname)){
	echo '<script>alert("First Name is Required")</script>';
}
else{
	if (!preg_match($validName,$fname)) {
		echo '<script>alert("Digits are not allowed")</script>';
		}
} 

//  Last Name Validation
if(empty($lname)){
$lnameErr="Last Name is Required"; 
}
else if (!preg_match($validName,$lname)) {
$lnameErr="Digits are not allowed";
}
else{
$lnameErr=true;
}

//Email Address Validation
if(empty($email)){
$emailErr="Email is Required"; 
}
else if (!preg_match($validEmail,$email)) {
$emailErr="Invalid Email Address";
}
else{
$emailErr=true;
}
 
// password validation 
// if(empty($psw)){
// $passErr="Password is Required"; 
// } 
// elseif (!preg_match($uppercasePassword,$psw) || !preg_match($lowercasePassword,$psw) || !preg_match($digitPassword,$psw) || !preg_match($symbolPassword,$psw) || !preg_match($minEightPassword,$psw) || preg_match($spacesPassword,$psw)) {
// $passErr="Password must be at least one uppercase letter, lowercase letter, digit, a special character with no spaces and minimum 8 length";
// }
// else{
// $passErr=true;
// }

// form validation for confirm password
// if($cpassword!=$psw){
// $cpassErr="Confirm Password doest Matched";
// }



	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$ano=$_POST['ano'];
	$hname=$_POST['hname'];
	$place=$_POST['place'];
	$phno=$_POST['phno'];
	$dist=$_POST['dopt'];
	$psw=$_POST['psw'];
	$rpsw=$_POST['rpsw'];
	$email=$_POST['email'];
	//$image=$_POST['image'];

	//$_SESSION['email'] =$email;
	//$_SESSION['psw']=$psw;

	$gender=$_POST['gender'];
	$role=$_POST['role'];
	// If upload button is clicked ...
	
if(isset($_POST['submit']))
{
	$filename = $_FILES["image"]['name'];
    $tempname = $_FILES["image"]["tmp_name"];    
	move_uploaded_file($tempname,"images/".$filename);
	

}
		$con=mysqli_connect("localhost:3308","root","","charitymain") ;
		$sql="INSERT INTO `registration`(`fname`, `lname`, `aadhar`, `hname`, `place`, `dist`, `phno`, `psw`, `email`, `gender`, `role`, `img`) VALUES ('$fname', '$lname', '$ano', '$hname', '$place', '$dist', '$phno', '$psw', '$email','$gender','$role','$filename')";

		if(mysqli_query($con,$sql))

		{
			//$sql1="INSERT INTO `login`(`email`, `psw`) VALUES  ('$email','$psw')";
			//mysqli_query($con,$sql1);

			$insert="INSERT INTO `bankaccount`(`fname`,`email`) VALUES ('$fname','$email')";
            mysqli_query($con,$insert);
			

		
			if(($psw==$rpsw))
			{
			header('Location:login.php');
			echo '<script>alert("Registered successfully")</script>';
		    }
			
		}
		else
		{
			

				echo '<script>alert("!Registration failed")</script>';
			
		}
		
		

		
}

?>
