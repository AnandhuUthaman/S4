<!DOCTYPE html>
<?php
	include'config.php';
  //session_start();
  //$user_id = $_SESSION['user_id'];
?>
<html>
  <head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet"  href="style.css"> 
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>
  
  
  
    <div class="container11">
        <h1 class="w3-padding-32 w3-center">Payment Form</h1>
		
<form action="pay.php" method="post">

  <div class="input-group1"> 
        
      <input type="text" placeholder = "Enter the price" name="price" ><br>
	  </div>
<br>


  <div class="input-group1"> 
        
      <input type="text" placeholder = "Enter your name" name="customername"><br>
	  </div>
	  
<br>
	 
  <div class="input-group1"> 
        
	  
      <input type="email" placeholder = "Enter your email" name="email"><br>
	  </div>
	  

  <div class="input-group1"> 
        <br>
	  
      <input type="text" placeholder = "Enter your contact number" name="contactno"><br>
	  </div>
	  
    <br>

  
<br>
<div class="input-group1">
<input type="submit" name="submit" value="Proceed To Pay">
</div>

</form>

      
  </div>
 
</body>

</html>