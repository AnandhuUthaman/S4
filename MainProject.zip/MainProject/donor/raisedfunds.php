<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{


?>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor | raised Funds</title>
    <link rel="stylesheet" href="raisedfunds.css">

    <style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	    margin-top: 0px;
      margin-left: 540px;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
  </style>
</head>
<body>

<header>
     <label for="check">
      <i class="fas fa-bars" id="sidebtn"></i>
     </label>
   <div class="left">
      <h3>Charit<span>ABLE</span> </h3>
   </div>

   <?php 
    $e=$_SESSION['email'];	    
	include('config.php');

	$chk="select * from bankaccount where email='$e'";
    $ch=mysqli_query($con,$chk);
	$row1=0;
	$row1=mysqli_fetch_assoc($ch);
	if($row1 == 0)
	{
		
?>		
	<div id="box" class="snackbar"><?php echo "Reminder! Bank Details Not Added."; ?></div>
  <script src="welcome.js"></script>
<?php  
	}
?>

   <div class="right">
      <form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">Logout</button>
</form>
      <!---<a href="logout.php" class="logoutbtn">Logout</a>------>
   </div>
</header>

<div class="sidebar">
<center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>

    <a href="home.php"><i class="fas fa-desktop"></i><span>Home</span></a>
   <a href="profile.php"><i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="raisedfunds.php"><i class="fas fa-comments-dollar"></i><span>Fund requests</span> </a>
   <a href="recentActions.php"><i class="fas fa-history"></i><span>Recent actions</span> </a>
   <a href="events.php"><i class="fas fa-calendar"></i><span>Events</span> </a>
   <a href="achievements.php"><i class="fas fa-book"></i><span>Achievements</span> </a>
   <a href="addFeedback.php"><i class="far fa-envelope"></i><span>Feedback&Suggestion</span> </a>
   <!----<a href="#"><i class="fas fa-info-circle"></i> <span>About</span> </a>
   <a href="#"> <i class="fas fa-sliders-h"></i><span>Settings</span> </a>---->



  </div>
<div class="table_responsive">


<?php
if($row1 == 0)
{
?>
  <div style="text-decoration: none !important; color: red;"><a href="bankAccDetails.php">Add Bank account details</a></div>
<?php  
}
?>
    <table>
      <thead>
        <tr>
          <th>S.no</th>
          <th>Purpose</th>
          <th>Client</th>
          <th>Description</th>
          <th>Fund raised by</th>
          <th>End on</th>
        <!--  <th>Fund collection</th>--->
          <th>Amount</th>
          <th>Pay amount</th>
          
          
        </tr>
      </thead>

      <tbody>
      </tr>
					
					<?php
						
						$sql="select * from fundraise fr,registration re where re.email=fr.email and fr.approval='accepted'";
						$sq=mysqli_query($con,$sql);
            $count=1;
						while($row=mysqli_fetch_assoc($sq))
						{						
						
					?>
					<tr>
					<td ><?php echo $count++ ?></td>
					<td ><?php echo $row['purpose'] ?></td>
          <td ><?php echo $row['client'] ?></td>
					<td ><?php echo $row['desc'] ?></td>
          <td ><?php echo $row['role'] ?></td>
          <td ><?php echo $row['end_date'] ?></td>
         
          
            <!----<?php

                   $chk="SELECT *,sum(famount) from fundraise fr, fundgiven fg where fr.id=fg.fundid";
                   $ch=mysqli_query($con,$chk);
                   
                   while($row1=mysqli_fetch_array($ch))
                   {
                             if($row1['amount'] <= $row1['sum(famount)'])
                             {
            ?>                  
                              <td><?php echo "Reached"; ?></td>
            <?php                  
                             }
                             else
                             {
            ?>                  
                              <td><?php echo "Ongoing"; ?></td>
            <?php                  
                             }
                   }
            ?>----->
					<td ><?php echo $row['amount'] ?></td>
          <td><?php
                   $today=date("Y-m-d");
                   if($row['end_date'] <= $today)
                   {
                            echo "Closed";                      
                        
                  }
                  else if($row['scope']=="closed")
                     {
                            echo $row['scope'];                      
                     }
                        else
                        {
              ?>
                          <button class="but1"><a href="RazorPay-PHP-Integration-with-DB-main/payment-form.php">Payment</a>	
              <?php
                        }
                      
              ?>
          </td>      									
			</tr>
           <?php 
               }
            ?>
      </tbody>
    </table>
  </div>
					
						
</body>
<html>
<?php
}
else
{
    header('location: ../index.php');
}
?>