<?php
include('config.php');
session_start();
$e=$_SESSION['email'];
//echo $e;
if(isset($_SESSION['email']))
{


?>
<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donor | Feedback</title>
  <link rel="stylesheet" href="addFeedback.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
	<style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	    margin-top: 0px;
      margin-left: 540px;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
  </style>
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>
  <?php 
    $e=$_SESSION['email'];	    
	include('config.php');

	$chk="select * from bankaccount where email='$e'";
    $ch=mysqli_query($con,$chk);
	$row=0;
	$row=mysqli_fetch_assoc($ch);
	if($row == 0)
	{
		
?>		
	<div id="box" class="snackbar"><?php echo "Reminder! Bank Details Not Added."; ?></div>
  <script src="welcome.js"></script>
<?php  
	}
?>
	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" id="logout" class="logoutbtn">Logout</button>
</form>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</header>
<div class="sidebar">
  	<center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>

   <a href="home.php"><i class="fas fa-desktop"></i><span>Home</span></a>
   <a href="profile.php"><i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="raisedfunds.php"><i class="fas fa-comments-dollar"></i><span>Fund requests</span> </a>
   <a href="recentActions.php"><i class="fas fa-history"></i><span>Recent actions</span> </a>
   <a href="events.php"><i class="fas fa-calendar"></i><span>Events</span> </a>
   <a href="achievements.php"><i class="fas fa-book"></i><span>Achievements</span> </a>
   <a href="addFeedback.php"><i class="far fa-envelope"></i><span>Feedback&Suggestion</span> </a>
   <!----<a href="#"><i class="fas fa-info-circle"></i> <span>About</span> </a>
   <a href="#"> <i class="fas fa-sliders-h"></i><span>Settings</span> </a>---->



  </div>


  <div class="wrapper" style="margin-left: 330px; margin-top:90px;">
    <h2 align="center">Send Feedback and Suggestions</h2>
    <form action="#">
      
      <div class="message">
        <textarea placeholder="Write your message" name="message"></textarea>
        <i class="material-icons"></i>
      </div>
      <div class="button-area">
        <button type="submit">Send Message</button>
        <span></span>
      </div>
    </form>
  </div>

  <script src="script.js"></script>

</body>
</html>
<?php
include('config.php');
if(isset($_POST['submit']))
{
    
  
    $email=$_SESSION['email'];
   
    $msg=$_POST['msg'];
    //echo $email;
    //echo $name;
    //echo $msg;

    $sql="INSERT into `feedback` values('$email','$msg')";
    $row=mysqli_query($con,$sql);
    if($row)
    {      
      echo '<script>alert("Thank you for giving feedback.")</script>';
    }
    else
    {
      echo '<script>alert("Failed to add")</script>';
    }
}
?>  

<?php
}
else
{
    header('location: ../index.php');
}
?>