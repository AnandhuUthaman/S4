
<?php
include('config.php');

session_start();
$email =$_SESSION['email']; 

?>
<!DOCTYPE html>
<html>
<head>
	<title>Donor | Home</title>
	<link rel="stylesheet" type="text/css" href="bankAccDetails.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	    margin-top: 70px;
      margin-left: 540px;
      background-color: white;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
  </style>
</head>
<body>
<header>
     <label for="check">
     	<i class="fas fa-bars" id="sidebtn"></i>
     </label>
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>

	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" id="logout" class="logoutbtn">Logout</button>
</form>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</header>
 
  <div class="sidebar">
  	<center>
  		<?php
  		        $sql="select * from registration where email='$email'";
				$sq=mysqli_query($con,$sql);
				while($row=mysqli_fetch_assoc($sq))
				{						
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
				}
			?>
  	</center>

   <a href="#"><i class="fas fa-desktop"></i><span>Home</span></a>
   <a href="profile.php"><i class="fas fa-user"></i><span>Profile</span> </a>
   <a href="raisedfunds.php"><i class="fas fa-comments-dollar"></i><span>Fund requests</span> </a>
   <a href="recentActions.php"><i class="fas fa-history"></i><span>Recent actions</span> </a>
   <a href="events.php"><i class="fas fa-calendar"></i><span>Events</span> </a>
   <a href="achievements.php"><i class="fas fa-book"></i><span>Achievements</span> </a>
   <a href="addFeedback.php"><i class="far fa-envelope"></i><span>Feedback&Suggestion</span> </a>
   <!----<a href="#"><i class="fas fa-info-circle"></i> <span>About</span> </a>
   <a href="#"> <i class="fas fa-sliders-h"></i><span>Settings</span> </a>---->
  </div>

  <div class="table_responsive" style="margin-left: 370px;">
  <table>
                    
    <thead>            
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" role="form" enctype="multipart/form-data">
                    <tr>
                      <td style="color: black;">Name&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="purpose" placeholder="Name of Account Holder" required>
                      </td>
                     
                    </tr>
                    <tr>
                        <td style="color: black;">Card Number &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="cno" placeholder="Card Number">
                    </tr>
                    <tr>
                        <td style="color: black;">Expire Month &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="date" value="" class="form-control mb-3" name="expmonth" placeholder="Expire Month" required>
                    </tr>
                    <tr>
                        <td style="color: black;">Expire Year &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="date" value="" class="form-control mb-3" name="expyear" placeholder="Expire Year" required>
                    </tr>
                       
                     <tr>
                        <td style="color: black;">CVV &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="cvv" placeholder="CVV"reqiured>
                     </tr>
                     <tr>
                      
                     <tr>
                        <td><input type="submit" name="submit" class="btn btn-primary btn-block" value="Submit"></td>
                     </tr>
          </thead>
    </table>
   </form>
</div>  

</body>
</html>
<?php
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit']))
{
	
    $account_holder=$_POST['name'];
    $email=$_SESSION['email'];
	$card_no=$_POST['cno'];
	$expire_month=$_POST['cno'];
    $amount= 20000;
    $expire_year=$_POST['cno'];
    $cvv=$_POST['cvv'];
 
  
  $sq5="INSERT INTO `bankaccount`(`name`, `email`, `cno`, `expmonth`, `amount`, `expyear`, `cvv`) VALUES('$account_holder','$email','$card_no','$expire_month','$amount','$expire_year','$cvv')";
  $sq3=mysqli_query($con,$sq5);
  $row5 = 0;
  $row5=mysqli_fetch_assoc($sq3);

    if($row5 != 0)
   {
        echo'<script>alert("Account Details added Successfully")</script>'; 
   }
   else
   {
        echo'<script>alert("Failed to add Account Details")</script>'; 
   }
}

?>