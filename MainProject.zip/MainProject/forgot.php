<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="forgot.css" />
    <title>CharitABLE | ForgotPassword</title>
</head>
<style>
    .dropbtn {
      background-color: white;
      color: black;
      padding: 0px;
      font-size: 1.12rem;
      font-weight: 1rem;
      border: none;
      cursor: pointer;
    }

    .dropdown {
      margin-left: 11px;
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      z-index: 1;
    }

    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {
      background-color: #f1f1f1
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown:hover .dropbtn {
      color: #ff7300;
    }
  </style>
<body>
<div style="width:100%; height:18px; background-color:darkblue; color:black; font-size:13px; position: relative;">
    <div style="margin-left:120px; color: white;">
    &#9993 charitable@gmail.com&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&#9990 +91 6238591004&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-twitter"></i>      <i class="fa fa-facebook"></i>
    </div>
</div>
<header>
    <!-- ********** ###### ********** -->
    <!-- ********** nav-bar ********** -->

    <nav>
    
     
        <ul>
          <li><a href="#" class="logo">CharitABLE</a></li>
          <!--<input class="search" type="text" placeholder="Search..">-->
          <li style="padding-left: 430px;"><a href="index.php">Home</a></li>
          <li><a href="contact.php">Contact us</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="#">News</a></li>
          <li><a href="login.php" class="active">Login</a></li>
          <li><a href="reg.php">Sign Up</a></li>
        </ul>
     
    </nav>
    <!-- ======================== Navigation-bar close **********======================================== -->



    <!--====================== ********** Past code ********** =========================================-->


    <!----<div class="container_box">
        <h1>Give, but <span>Give</span> until it hurts</h1>
        <p style="font-size:15px;">
          You have not lived today until you have done something for someone who can never repay you.
        </p>
        <a class="button" href="login.php">Get start</a>--->
       
  </div>
  

  </header>
    <center>
        <div class="wrapper">
            <header>Reset Password</header>
            <form action="" method="post">
                <div class="field email">
                    <div class="input-area">
                        <input type="text" id="email" name="email" placeholder="Email Address">
                    </div>
                </div>
                <div class="field password">
                    <div class="input-area">
                        <input type="password" id="psw" name="psw" placeholder="Password">
                    </div>
                </div>
                <div class="field password">
                    <div class="input-area">
                        <input type="password" id="rpsw" name="rpsw" placeholder="Retype Password">
                    </div>
                </div>

                <input type="submit" onclick="" name="submit" value="Submit">
                <input type="submit" onclick="" name="reset" value="Reset">
            </form>
        </div>
    </center>

<div style="width: 100%; height: 200px; background-color: whitesmoke; margin-top:637px; position: relative;">
    <div style="width:230px; height: 100px; color: indigo; font-size: 3rem; margin-top: 70px; margin-left: 70px;"><h3>Charit<span>ABLE</span></h3></div>
</div>


</body>
</html>
<?php
session_start();
include('config.php');

if (isset($_POST['submit'])) {


    $email = $_POST['email'];
    $psw = $_POST['psw'];
    $rpsw = $_POST['rpsw'];

    $sql = "SELECT * FROM `registration` WHERE email='$email'";
    $re = mysqli_query($con, $sql);
    if ($row = mysqli_fetch_array($re)) {
        if ($row['email'] == $email) {
            if ($psw == $rpsw) {
                $sq = "UPDATE `registration` SET `psw`='$psw' WHERE email='$email'";
                mysqli_query($con, $sq);

                echo '<script>alert("Changed")</script>';
            } else {
                echo '<script>alert("Password and Retype password field must be same")</script>';
            }
        }
    } else {
        echo '<script>alert("No account exist with this email address")</script>';
    }
}
?>