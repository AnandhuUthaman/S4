<!-- <?php
//include('config.php');
//$sql = "SELECT * FROM registration ";
//$aResult = mysqli_query($con,$sql);
//if($_REQUEST['frm_action'] == 3)
//{
     //if ($_REQUEST['cust_id'] == 0)
     //{
        //$id = $_REQUEST['cust_id'];
        //$sqlCustomer = "SELECT * FROM registration ";
    // }
    // else if($_REQUEST['cust_id'] == 1)
    // {
    //    $id = $_REQUEST['cust_id'];
     //   $sqlCustomer = "SELECT * FROM registration WHERE id ='$id'";
     //}
     //$aCustomer = mysqli_query($con,$sqlCustomer);
//}
?> -->
<html>
<head>
<script type="text/javascript">
function changeSID()
{
oForm       = eval(document.getElementById("frmForm"));
iCustomerId = document.getElementById("sid").value;
url         = "demo.php?frm_action=3&cust_id=" +iCustomerId;
document.location = url;
}
</script>
</head>

<body>
<form name="frmForm" id="frmForm" >
<table border="0" cellspacing="2" cellpadding="2" width="40%">
<tr>
<td align="right" ><strong>Sid</strong></td>
<td align="left"><select name="sid" id="sid" onchange="javascript:changeSID();">
<option value="">Select</option>
<option value="0">Normal</option> 
<option value="1">Event</option> 


<!-- <?php
//$sid1 = $_REQUEST['cust_id'];

    //while($rows=mysqli_fetch_array($aResult,MYSQLI_ASSOC))
    //{
        // $id  = $rows['id'];
         //$sid = $rows['sid'];
         //if($sid1 == $id)
         //{
            //$chkselect = 'selected';

         //}
         //else
         //{
            //$chkselect ='';
         //}
?> -->
<!-- <option value="<?php //echo  $id;?>"<?php //echo $chkselect;?>><?php //echo $sid;?></option> -->
<!-- <?php 
    //} 
?> -->
</td>
</tr>
<!-- <?php 
//if($_REQUEST['frm_action'] == 3) 
//{ 
?> -->
<tr>
<td colspan="2">
<div   style="width: 60%; background-color: whitesmoke;">
<tr bgcolor="#EFEFEF">
<td><b><font color='Red'>Sid</font></b></td>
<td><b><font color='Red'>first name</font></b></td>
<td><b><font color='Red'>last name</font></b></td>
</tr>
<!-- <?php
//while($row1 = mysqli_fetch_array($aCustomer,MYSQLI_ASSOC))
//{
//$sid   = $row1['id'];
//$sname = $row1['fname'];
//$age   = $row1['lname'];
?> -->
<tr bgcolor="#FFFFFF">
<td><b><font color='#663300'><?php //echo $id;?></font></b></td>
<td><b><font color='#663300'><?php //echo $fname;?></font></b></td>
<td><b><font color='#663300'><?php //echo $lname;?></font></b></td>
</tr>
<!-- <?php //} ?> -->
</table>
</td>
</tr>
<!-- <?php //} ?> -->
</table>
</form>
</body>
</html>