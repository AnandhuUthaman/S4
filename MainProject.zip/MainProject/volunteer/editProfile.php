<?php
include('config.php');
session_start();
$e = $_SESSION['email'];
//echo $e;
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <!--TITLE-->
  <title>Voluteer | Profile</title>

  <!--ICON-->
  <link rel="shortcut icon" href="/DevanagariBrahmi/logo.png">

  <!--META TAGS-->
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="author" content="Team Bboysdreamsfell">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta property="og:locale" content="en_US" />
  <meta property="og:url" content="" />
  <meta property="og:site_name" content="Profiler Name || Krishivalahs" />

  <!--EXTERNAL CSS-->
  <link rel="stylesheet" href="editProfile.css">



  <!--PLUGIN-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <!--FONT AWESOME-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!--GOOGLE FONTS-->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Odibee+Sans&family=Oswald:wght@300;400&family=Ubuntu:wght@700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Pattaya&display=swap" rel="stylesheet">

<body>

<header>
     
     <div class="left">
       <h3>Charit<span>ABLE</span> </h3>
     </div>
   
     <div class="right">
       <form action="logout.php" method="POST"> 
         <button type="submit" name="logout" class="logoutbtn">Logout</button>
   </form>
       <!---<a href="logout.php" class="logoutbtn">Logout</a>------>
     </div>
</header>
       <input type="checkbox" id="check">
       <label for="check">
         <i class="fas fa-bars" id="btn"></i>
         <i class="fas fa-bars" id="cancel"></i>
       </label>
       <div class="sidebar">
       <center>
         <?php
               $e=$_SESSION['email'];
             
               include('config.php');
           $sql="select * from registration where email='$e'";
   
               $sq=mysqli_query($con,$sql);
               while($row=mysqli_fetch_assoc($sq))
               {	
           ?>
                 <img src="../images/<?php echo $row['img']; ?>" class="profile"> 
             
         <h4 style="font-size: 0px;"><?php echo $row['fname'];?></h4>
             <?php
               }
             ?>
       </center>
       <a href="home.php" class="active">
       
       <span>Home</span>
     </a>
     <a href="profile.php">
      
       <span>Profile</span>
     </a>
    <a href="serviceRequest.php">
       
       <span>Service Request</span>
     </a>
     <a href="notifications.php">
       
       <span>Notifications</span>
     </a>
     <!---<a href="activities.php">
     
       <span>Activities</span>
     </a>--->
    <a href="feedback.php">
      
       <span>Feedback&Suggestion</span>
     </a>
     <!---<a href="viewAchievements.php">
      
       <span>Achievements</span>
     </a>--->
     <!---<a href="#">
       <i class="far fa-envelope"></i>
       <span>Feedback</span>
     </a>--->
       </div>

  <!----------------------------------------->
<div class="container" style="margin-left: 340px;">
<table >
<tr>
<td>
<section style="margin-top: 40px;">
   <br>
<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" id="blah" alt="Avatar"> 


  		<center><h2 style="font-size:22px;"><?php echo $row['fname'];?></h2></center>
  		   
<center><h3>Volunteer</h3></center>
<!---<form>

</form>---->

</td>
</section>
<td>
<div class="table_responsive">   
  <table>           
            <form action="" method="POST" role="form" enctype="multipart/form-data">
                    <tr>
                       <td>First name </td>
                       <td><input type="text" value=""class="form-control mb-3" name="fname" placeholder="First name" required></td>
                    </tr>
                    <tr>
                        <td>Last name</td>
                        <td><input type="text" value="" class="form-control mb-3" name="lname" placeholder="Last name" required></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><input type="text" value="" class="form-control mb-3" name="phno" placeholder="Contact number" required></td>
                    </tr>
                    <tr>
                       <td>Address</td>
                       <td><input type="text" name="hname" id="hname" placeholder="Address" required/></td>
                    </tr>
                    <tr>
                        <td>Place</td>
                        <td><input type="text" name="place" id="place" placeholder="Place" required/></td>
                     </tr>
                     <tr>
                        <td>District</td>
                        <td>
                           <select id="dopt" name="dopt" >   
                              <option name="District" value="none" selected disabled hidden>Select District</option> 
                              <option name="Kottayam">Kottayam</option>
                              <option name="Idukki">Idukki</option>
                              <option name="Kollam">Kollam</option>
                              <option name="Alappuzha">Alapuzha</option>
                              <option name="Trivandrum">Trivandrum</option>
                              <option name="Ernakulam">Ernakulam</option>
                              <option name="Pathanamthitta">Pathanamthitta</option>
                              <option name="Thrissur">Thrissur</option>
                              <option name="Palakkad">Palakkad</option>
                              <option name="Kozhikkode">Kozhikkod</option>
                              <option name="Kannur">Kannur</option>
                              <option name="Wayanad">Wayanad</option>
                              <option name="Malappuram">Malappuram</option>
                              <option name="Kasargod">Kasargod</option>
                           </select>
                        </td>
                     </tr>
                     <tr>
                        <td>Change&nbsp;Photo</td>
                        <td><input type="file" value="" class="form-control mb-3" name="image" required></td>
                     </tr>
                     <tr>
                        <td><input type="submit" name="submit" value="Submit" style="width:60px; height: 30px; margin-bottom: 60px; background-color: blue; cursor:pointer;"></td>
                     </tr>
            </form>
   </table>
 </div>
</td>

</ul>
</td>
</tr>

<?php
		}
?>

</table>
</div>


<!--JAVASCRIPT-->

</body>
</html>
<?php

if(isset($_POST['submit']))
{

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_SESSION['email'];
$phno=$_POST['phno'];
$hname=$_POST['hname'];
$place=$_POST['place'];
$dist=$_POST['dopt'];


   if(isset($_POST['submit']))
   {
          $filename = $_FILES["image"]['name'];
          $tempname = $_FILES["image"]["tmp_name"];    
          move_uploaded_file($tempname,"images/".$filename);
   }
   
   $sql="UPDATE registration SET fname='$fname',lname='$lname',phno='$phno',hname='$hname',place='$place',dist='$dist',img='$filename' where email='$email'";
   $sq=mysqli_query($con,$sql);
   $row=mysqli_fetch_array($sq);
   if($row)
   {
      echo '<script>alert(" details Changed")</script>';
   }
   else
   {
      echo '<script>alert("Failed")</script>';
   }

}

?>