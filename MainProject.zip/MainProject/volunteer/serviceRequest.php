<?php

session_start();
$email=$_SESSION['email']; 
?>
<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Volunteer | Home</title>
    <link rel="stylesheet" href="serviceRequest.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  </head>
  <body>
  <header>
     
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>

	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">Logout</button>
</form>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</header>
    <input type="checkbox" id="check">
    <label for="check">
      <i class="fas fa-bars" id="btn"></i>
      <i class="fas fa-bars" id="cancel"></i>
    </label>
    <div class="sidebar">
	  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
                            <h5 style="font-size:17px;"><?php echo $row['fname'];?></h5>
  		    <?php
						}
					?>
  	</center>
      <a href="home.php">
       
       <span>Home</span>
     </a>
     <a href="profile.php">
      
       <span>Profile</span>
     </a>
    <a href="serviceRequest.php" class="active">
       
       <span>Service Request</span>
     </a>
     <a href="notifications.php">
       
       <span>Notifications</span>
     </a>
    <!--- <a href="activities.php">
     
       <span>Activities</span>
     </a>--->
     <a href="feedback.php">
      
       <span>Feedback&Suggestion</span>
     </a>
     <!--<a href="viewAchievements.php">
      
       <span>Achievements</span>
     </a>--->
     <!---<a href="#">
       <i class="far fa-envelope"></i>
       <span>Feedback</span>
     </a>--->
    </div>

<div class="table_responsive" style="margin-left: 250px;">
    <table  style="margin-top: 90px; background-color: whitesmoke;">
    
    <thead>
        <tr>
          <th>S.no</th>
          <th>Description</th>
         
          <th>Activities of Volunteer</th>
          <th>Total Volunteers needed</th>
          <th>Interested Volunteers</th>
          <th>Give Support</th>
          <th>Details</th>
          
          
        </tr>
      </thead>
                    <?php
						
						$sql="select *,count(vid) from events ev, volunteer vr, registration re where ev.eid=vr.event_id and vr.email=re.email and vr.email='$email'";
						$sq=mysqli_query($con,$sql);
                        $count=1;
						while($row=mysqli_fetch_assoc($sq))
						{						
						
					?>

               <tbody>            
                
                    <tr>
                      <td><?php echo $count++; ?></td>
                      <td><?php echo $row['description']; ?></td>
                      <td><?php echo $row['v_role']; ?></td>
                      <td><?php echo $row['volunteer_count']; ?></td>
                      <td><?php echo $row['count(vid)']; ?></td>
                      <?php
                      if($row['v_status'] == "not interested")
                      {
                      ?>  
                          <td><button><a href="supportActions.php?eid=<?php echo $row['event_id'] ?>">Give support</a></button></td>
                          <td><button><a href="eventDetails.php?value=<?php echo $row['eid'] ?>">Details</a></button></td>
                      <?php
                      }
                      else
                      {
                      ?> 
                          <td><?php echo "Interest added  "; ?><button><a href="removeActions.php?value=<?php echo $row['vid'] ?>">Cancel</a></button></td>
                          <td><button><a href="eventDetails.php?value=<?php echo $row['eid'] ?>">Details</a></button></td>
                    <?php   
                      }
                      ?>
                    </tr>
                    <?php
						}
					?>
               </tbody>
        </table>
 
</div>
<div style="width: 450px; height:20px; background-color: skyblue; opacity: 0.9; color: black; margin-top: 10px; margin-left: 270px;">
<h5">Before giving interest, read the following informations carefully.</h5>               
</div>  
<div style="width: 900px; height:70px; background-color: orange; opacity: 0.9; color: black; margin-top: 10px; margin-left: 270px;">
<h4>Terms and Conditions</h4>
<p style="font-size: 12px;">Remember this is an official announce of request for physical help which will tell us service. There is no profit or wages get through this activity. Your are invited for your supports like a service to the society. So don't get abuse.If you are interested in charity and volunteering services, you can support for us. If you are physically disabled, don't get ready for the services. We will take actions if you enter fake informations.</p>
</div>
</body>
</html>