<?php

session_start();
$email=$_SESSION['email']; 
?>
<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Volunteer | Home</title>
    <link rel="stylesheet" href="eventDetails.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  </head>
  <body>
  <header>
     
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>

	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">Logout</button>
</form>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</header>
    <input type="checkbox" id="check">
    <label for="check">
      <i class="fas fa-bars" id="btn"></i>
      <i class="fas fa-bars" id="cancel"></i>
    </label>
    <div class="sidebar">
	  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
                            <h5 style="font-size:17px;"><?php echo $row['fname'];?></h5>
  		    <?php
						}
					?>
  	</center>
      <a href="home.php">
       
       <span>Home</span>
     </a>
     <a href="profile.php">
      
       <span>Profile</span>
     </a>
    <a href="serviceRequest.php" class="active">
       
       <span>Service Request</span>
     </a>
     <a href="notifications.php">
       
       <span>Notifications</span>
     </a>
    <!-- <a href="activities.php">
     
       <span>Activities</span>
     </a>--->
     <a href="feedback.php">
      
       <span>Feedback&Suggestion</span>
     </a>
     <!--<a href="viewAchievements.php">
      
       <span>Achievements</span>
     </a>--->
     <!---<a href="#">
       <i class="far fa-envelope"></i>
       <span>Feedback</span>
     </a>--->
    </div>

<div class="table_responsive" style="margin-left: 250px;">
    <table  style="margin-top: 90px; background-color: whitesmoke;">
    
    <thead>
        <tr>
          <th>S.no</th>
          <th>Description</th>
         
          <th>Client name</th>
          <th>Organization/Institution name</th>
          <th>Place</th>
          <th>District</th>
          <th>Function conduction date</th>
          
          
        </tr>
      </thead>
                    <?php
                        $ev_id=$_GET['value'];
						
						$sql1="select * from events where eid='$ev_id'";
						$sq1=mysqli_query($con,$sql1);
                        $count=1;
						while($row1=mysqli_fetch_assoc($sq1))
						{						
						
					?>

               <tbody>            
                   
                    <tr>
                      <td><?php echo $count++; ?></td>
                      <td><?php echo $row1['description']; ?></td>
                      <td><?php echo $row1['client_name']; ?></td>
                      <td><?php echo $row1['org_name']; ?></td>
                      <td><?php echo $row1['place']; ?></td>
                      <td><?php echo $row1['district']; ?></td>
                      <td><?php echo $row1['event_date']; ?></td>
                    </tr>
               </tbody>
               <?php
                        }
                        ?>
        </table>
  
</div>
 
</body>
</html>