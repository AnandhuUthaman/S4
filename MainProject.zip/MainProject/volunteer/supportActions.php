<?php
session_start();
$email=$_SESSION['email'];

include("config.php");

$id = $_GET['eid'];
echo "$email";
$status = "closed";
echo "$id";

    $sql = "INSERT INTO volunteer (event_id,email,v_status)  VALUES ($id,'$email','interested')";
    $res=mysqli_query($con,$sql);
    if($res)
    {
?>
    <script>
        alert("added");
        window.location = "serviceRequest.php";
    </script>
<?php
    }
   else 
    {
?>
    <script>
        alert("Failed");
        window.location = "serviceRequest.php";
    </script>

<?php
    }
  
?>