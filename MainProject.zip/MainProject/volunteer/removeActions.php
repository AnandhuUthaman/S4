<?php
session_start();
$email=$_SESSION['email'];

include("config.php");

$id = $_GET['value'];
echo "$email";
$status = "closed";
echo "$id";

    $sql = "UPDATE `volunteer` SET `status`= 'cancelled' where vid='$id'";
    $res=mysqli_query($con,$sql);
    if($res)
    {
?>
    <script>
        alert("Cancelled");
        window.location = "serviceRequest.php";
    </script>
<?php
    }
   else 
    {
?>
    <script>
        alert("Failed");
        window.location = "serviceRequest.php";
    </script>

<?php
    }
  
?>