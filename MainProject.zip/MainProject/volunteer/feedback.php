<?php

session_start();
$email = $_SESSION['email']; 
?>
<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- <title>Responsive Sidebar Menu</title> -->
    <link rel="stylesheet" href="feedback.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  	<style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	    margin-top: 0px;
      margin-left: 540px;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
    </style>
  </head>
  <body>
  <div class="navbar">
     
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>
  <!---<?php 
    $e=$_SESSION['email'];	    
	include('config.php');

	$chk="select * from clientaccount where email='$e'";
    $ch=mysqli_query($con,$chk);
	$row=0;
	$row=mysqli_fetch_assoc($ch);
	if($row == 0)
	{
		
?>	
	<div id="box" class="snackbar"><?php echo "Reminder! Bank Details Not Added."; ?></div>
  <script src="welcome.js"></script>
<?php  
	}
?>---->
	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">Logout</button>
</form>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</div>
    <input type="checkbox" id="check">
    <label for="check">
      <i class="fas fa-bars" id="btn"></i>
      <i class="fas fa-bars" id="cancel"></i>
    </label>
    <div class="sidebar">
	  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
              <h5 style="font-size:17px;"><?php echo $row['fname'];?></h5>
  		    <?php
						}
					?>
  	</center>
    <a href="home.php">
       
        <span>Home</span>
      </a>
      <a href="profile.php">
       
        <span>Profile</span>
      </a>
     <a href="serviceRequest.php">
        
        <span>Service Request</span>
      </a>
      <a href="notifications.php">
        
        <span>Notifications</span>
      </a>
      <!---<a href="activities.php">
      
        <span>Activities</span>
      </a>--->
	  <a href="feedback.php" class="active">
       
        <span>Feedback&Suggestion</span>
      </a>
      <!---<a href="viewAchievements.php">
       
        <span>Achievements</span>
      </a>--->
      <!---<a href="#">
        <i class="far fa-envelope"></i>
        <span>Feedback</span>
      </a>--->
    </div>

<!----feedback section------------------------->
    <div class="wrapper">
    <h2 align="center">Send Feedback and Suggestions</h2>
    <form action="#">
      
      <div class="message">
        <textarea placeholder="Write your message" name="message"></textarea>
        <i class="material-icons"></i>
      </div>
      <div class="button-area">
        <button type="submit">Send Message</button>
        <span></span>
      </div>
    </form>
  </div>
 

<!--<center><div id="box" class="box" style="height: 150px; width: 300px;  background: red">

</div></center>
<script src="welcome.js"></script>---->
</body>
</html>
<?php
include('config.php');
if(isset($_POST['submit']))
{
    
    $name=$_POST['name'];
    $email=$_POST['email'];
    $email=$_POST['phone'];
    $msg=$_POST['msg'];
    //echo $email;
    //echo $name;
    //echo $msg;

    $sql="INSERT into `feedback` values('$name','$email','$phone','$msg')";
    $row=mysqli_query($con,$sql);
    if($row)
    {      
      echo '<script>alert("Thank you for giving feedback.")</script>';
    }
    else
    {
      echo '<script>alert("Failed to add")</script>';
    }
}
?> 