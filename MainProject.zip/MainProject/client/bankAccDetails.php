
<?php
include('config.php');
session_start();
$e = $_SESSION['email'];
//echo $e;
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <!--TITLE-->
  <title>Profiler Name || Krishivalahs</title>

  <!--ICON-->
  <link rel="shortcut icon" href="/DevanagariBrahmi/logo.png">

  <!--META TAGS-->
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="author" content="Team Bboysdreamsfell">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta property="og:locale" content="en_US" />
  <meta property="og:url" content="" />
  <meta property="og:site_name" content="Profiler Name || Krishivalahs" />

  <!--EXTERNAL CSS-->
  <link rel="stylesheet" href="bankAccDetails.css">



  <!--PLUGIN-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <!--FONT AWESOME-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!--GOOGLE FONTS-->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Odibee+Sans&family=Oswald:wght@300;400&family=Ubuntu:wght@700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Pattaya&display=swap" rel="stylesheet">
	<style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	    margin-top: 0px;
      margin-left: 540px;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
  </style>
</head>
<body>

<header>
     
     <div class="left">
       <h3>Charit<span>ABLE</span> </h3>
     </div>
  
     <div class="right">
       <form action="logout.php" method="POST"> 
         <button type="submit" name="logout" class="logoutbtn">Logout</button>
   </form>
       <!---<a href="logout.php" class="logoutbtn">Logout</a>------>
     </div>
</header>
       <input type="checkbox" id="check">
       <label for="check">
         <i class="fas fa-bars" id="btn"></i>
         <i class="fas fa-bars" id="cancel"></i>
       </label>
       <div class="sidebar">
       <center>
         <?php
               $e=$_SESSION['email'];
             
               include('config.php');
           $sql="select * from registration where email='$e'";
   
               $sq=mysqli_query($con,$sql);
               while($row=mysqli_fetch_assoc($sq))
               {	
           ?>
                 <img src="../images/<?php echo $row['img']; ?>" class="profile"> 
             
         <h4><?php echo $row['fname'];?></h4>
             <?php
               }
             ?>
       </center>
         <a href="home.php">
           <i class="fas fa-desktop"></i>
           <span>Home</span>
         </a>
         <a href="profile.php" class="active">
           <i class="fas fa-user"></i>
           <span>Profile</span>
         </a>
         <a href="requestAction.php">
           <i class="fas fa-comment-dollar"></i>
           <span>Request action</span>
         </a>
         <a href="actionTaken.php">
            <i class="fas fa-calendar"></i>
           <span>Action taken</span>
         </a>
         <a href="actionHistory.php">
           <i class="fas fa-history"></i>
           <span>Recent activities</span>
         </a>
      <!--- <a href="viewAchievements.php">
           <i class="fas fa-book"></i>
           <span>Achievements</span>
         </a>--->
        <!--- <a href="#">
           <i class="fas fa-sliders-h"></i>
           <span>Services</span>
         </a>--->
         <a href="feedback.php">
           <i class="far fa-envelope"></i>
           <span>Feedback</span>
         </a>
       </div>

  <div class="table_responsive" style="margin-left: 370px;">
  <table>
                    
    <thead>            
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" role="form" enctype="multipart/form-data">
                    <tr>
                      <td style="color: black;">Account Holder&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="acc_holder" placeholder="Name of Account Holder" required>
                      </td>
                     
                    </tr>
                    <tr>
                        <td style="color: black;">Account number&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="acc_no" placeholder="Account Number">
                    </tr>
                    <tr>
                        <td style="color: black;">Branch &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="branch" placeholder="Branch of Bank" required>
                    </tr>
                    <tr>
                        <td style="color: black;">IFSC Code &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="ifsc" placeholder="IFSC Code" required>
                    </tr>
                       
                     <tr>
                        <td><input type="submit" name="submit" class="btn btn-primary btn-block" value="Submit"></td>
                     </tr>
          </thead>
    </table>
   </form>
</div>  

</body>
</html>
<?php
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit']))
{
	
    $email=$_SESSION['email'];
	  $account_no=$_POST['acc_no'];
    $branch=$_POST['branch'];
    $ifsc_code=$_POST['ifsc'];
    $account_holder=$_POST['acc_holder'];
    $amount= 20000;
 
  
  $sq5="INSERT INTO `clientaccount`(`email`, `acc_no`, `branch`, `ifsc_code`, `acc_holder`, `amount`) VALUES (' $email','$account_no','$branch','$ifsc_code','$account_holder','$amount')";
  $sq3=mysqli_query($con,$sq5);
  $row5 = 0;
  $row5=mysqli_fetch_assoc($sq3);

    if($row5 != 0)
   {
        echo'<script>alert("Account Details added Successfully")</script>'; 
   }
   else
   {
        echo'<script>alert("Failed to add Account Details")</script>'; 
   }
}

?>