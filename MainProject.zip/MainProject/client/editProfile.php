<?php

session_start();
$email = $_SESSION['email']; 
if(isset($_SESSION['email']))
{

?>
<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- <title>Responsive Sidebar Menu</title> -->
    <link rel="stylesheet" href="editProfile.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  	<style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	    margin-top: 0px;
      margin-left: 540px;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
    </style>
  </head>
  <body>
  <div class="navbar">
     
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>
  <?php 
    $e=$_SESSION['email'];	    
	include('config.php');

	$chk="select * from clientaccount where email='$e'";
    $ch=mysqli_query($con,$chk);
	$row=0;
	$row=mysqli_fetch_assoc($ch);
	if($row == 0)
	{
		
?>		
	<div id="box" class="snackbar"><?php echo "Reminder! Bank Details Not Added."; ?></div>
  <script src="welcome.js"></script>
<?php  
	}
?>
	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">Logout</button>
</form>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</div>
    <input type="checkbox" id="check">
    <label for="check">
      <i class="fas fa-bars" id="btn"></i>
      <i class="fas fa-bars" id="cancel"></i>
    </label>
    <div class="sidebar">
	  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
      <a href="home.php">
        <i class="fas fa-desktop"></i>
        <span>Home</span>
      </a>
      <a href="profile.php" class="active">
        <i class="fas fa-user"></i>
        <span>Profile</span>
      </a>
      <a href="requestAction.php">
        <i class="fas fa-comment-dollar"></i>
        <span>Request action</span>
      </a>
      <a href="actionTaken.php">
         <i class="fas fa-calendar"></i>
        <span>Action taken</span>
      </a>
      <a href="actionHistory.php">
        <i class="fas fa-history"></i>
        <span>Recent activities</span>
      </a>
	  <!--<a href="viewAchievements.php">
        <i class="fas fa-book"></i>
        <span>Achievements</span>
      </a>--->
      <!---<a href="#">
        <i class="fas fa-sliders-h"></i>
        <span>Services</span>
      </a>--->
      <a href="feedback.php">
        <i class="far fa-envelope"></i>
        <span>Feedback</span>
      </a>
    </div>

<!----------------------------------------->
<div class="container" style="margin-left: 340px;">
<table >
<tr>
<td>
<section style="margin-top: 40px;">
   <br>
<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" id="blah" alt="Avatar"> 


  		<center><h1><?php echo $row['fname'];?></h1></center>
  		   
<center><h3>Client</h3></center>
<!---<form>

</form>---->

</td>
</section>
<td>
<div class="table_responsive">   
  <table>           
            <form action="" method="POST" role="form" enctype="multipart/form-data">
                    <tr>
                       <td>First name </td>
                       <td><input type="text" value=""class="form-control mb-3" name="fname" placeholder="First name" required></td>
                    </tr>
                    <tr>
                        <td>Last name</td>
                        <td><input type="text" value="" class="form-control mb-3" name="lname" placeholder="Last name" required></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><input type="text" value="" class="form-control mb-3" name="phno" placeholder="Contact number" required></td>
                    </tr>
                    <tr>
                       <td>Address</td>
                       <td><input type="text" name="hname" id="hname" placeholder="Address" required/></td>
                    </tr>
                    <tr>
                        <td>Place</td>
                        <td><input type="text" name="place" id="place" placeholder="Place" required/></td>
                     </tr>
                     <tr>
                        <td>District</td>
                        <td>
                           <select id="dopt" name="dopt" >   
                              <option name="District" value="none" selected disabled hidden>Select District</option> 
                              <option name="Kottayam">Kottayam</option>
                              <option name="Idukki">Idukki</option>
                              <option name="Kollam">Kollam</option>
                              <option name="Alappuzha">Alapuzha</option>
                              <option name="Trivandrum">Trivandrum</option>
                              <option name="Ernakulam">Ernakulam</option>
                              <option name="Pathanamthitta">Pathanamthitta</option>
                              <option name="Thrissur">Thrissur</option>
                              <option name="Palakkad">Palakkad</option>
                              <option name="Kozhikkode">Kozhikkod</option>
                              <option name="Kannur">Kannur</option>
                              <option name="Wayanad">Wayanad</option>
                              <option name="Malappuram">Malappuram</option>
                              <option name="Kasargod">Kasargod</option>
                           </select>
                        </td>
                     </tr>
                     <tr>
                        <td>Change&nbsp;Photo</td>
                        <td><input type="file" value="" class="form-control mb-3" name="image" required></td>
                     </tr>
                     <tr>
                        <td><input type="submit" name="submit" value="Submit" style="width:60px; height: 30px; background-color: blue; cursor:pointer;"></td>
                     </tr>
            </form>
   </table>
 </div>
</td>

</ul>
</td>
</tr>

<?php
		}
?>

</table>
</div>


<!--JAVASCRIPT-->

</body>
</html>
<?php

if(isset($_POST['submit']))
{

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_SESSION['email'];
$phno=$_POST['phno'];
$hname=$_POST['hname'];
$place=$_POST['place'];
$dist=$_POST['dopt'];


   if(isset($_POST['submit']))
   {
          $filename = $_FILES["image"]['name'];
          $tempname = $_FILES["image"]["tmp_name"];    
          move_uploaded_file($tempname,"images/".$filename);
   }
   
   $sql="UPDATE registration SET fname='$fname',lname='$lname',phno='$phno',hname='$hname',place='$place',dist='$dist',img='$filename' where email='$email'";
   $sq=mysqli_query($con,$sql);
   $row=mysqli_fetch_array($sq);
   if($row)
   {
      echo '<script>alert(" details Changed")</script>';
   }
   else
   {
      echo '<script>alert("Failed")</script>';
   }

}

?>


<?php
}
else
{
    header('location: ../index.php');
}
?>