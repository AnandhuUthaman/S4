setTimeout(() => {
    const box = document.getElementById('box');
    box.style.display = 'none';

}, 1000);