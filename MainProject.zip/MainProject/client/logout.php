<!DOCTYPE html>
<html>
<head>
  <SCRIPT type="text/javascript" language="javascript">
    window.history.forward();
    function noBack() 
    {

     window.history.forward();
    }
</SCRIPT>  
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">

<?php
session_start();
$e=$_SESSION['email'];
include('config.php');

   if(isset($_POST['logout']))
   {

     $sql="delete from login where utype='user' AND email='$e'";
     mysqli_query($con,$sql);

       session_destroy();
       unset($_SESSION['email']);
       header('location:../index.php');

   }
?>
</body>
</html>