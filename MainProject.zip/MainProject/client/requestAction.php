
<?php
include('config.php');
session_start();
$e = $_SESSION['email'];
//echo $e;

$purposeErr = $descriptionErr = $end_dateErr = $fileToUploadErr = $expect_amountErr = $fileupload_status = "";
?>


<?php


if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit']))
{
   // Purpose Validation
  if(empty($_POST["purpose"]))
  {
    $purposeErr="Reqiured";
  }
   // Description Validation
   if(empty($_POST["description"]))
   {
     $descriptionErr="Reqiured";
   }
   //end date validation
   if(empty($_POST["end_date"]))
   {
     $end_dateErr="Reqiured";
   } 
   //file upload validation
   if(empty($_POST["fileToUpload"]))
   {
  
     $fileToUploadErr="Required";
     $fileupload_status="File was not uploaded.";
  
   }
   //Amount field validation
   if(empty($_POST["amount"]))
   {
     $expect_amountErr="Reqiured";
   }


   $validdigit = "/(?=.*?[0-9])/";
   $validCharacters="/^[a-zA-Z ]*$/";

   function test_input($data)
   {
     
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     
     return $data;
   }



   $email=$_SESSION['email'];
   $title=test_input($_POST['purpose']);
   $desc=test_input($_POST['desc']);
   $start_date=date("Y-m-d");
   $end_date=$_POST['end_date'];
   $amount=test_input($_POST['expect_amount']);

//upload documents(pdf only)   
$filename = $_FILES["fileToUpload"]['name'];
$target_dir = "uploads/pdf/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$temp = explode(".", $_FILES["fileToUpload"]["name"]);
$extension = end($temp);

     
// Check if file already exists
if (file_exists($target_file)) {
  $fileupload_status="Sorry, file already exists.";
   $uploadOk = 0;
 }
 
 // Check file size
 if ($_FILES["fileToUpload"]["size"] > 500000) {
 
   $fileupload_status="Sorry, your file is too large."; 
   $uploadOk = 0; 
  
 }
      // Check if $uploadOk is set to 0 by an error
      if(!empty('fileToUpload'))
      {
              if ($uploadOk == 0) 
              {
 
                     $fileupload_status="Sorry, your file was not uploaded.";

              }
      }         
       // if everything is ok, try to upload file
      else 
      {
            if (!empty('fileToUpload') && move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],"uploads/pdf/" . $_FILES["fileToUpload"]["name"])) 
            {
                echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
            } 
            else 
            {
   
                $fileupload_status="Sorry, there was an error uploading your file.";
     
           }
      }

   
      if($amount == 0 || $amount < 0)
      {   
         echo'<script>alert("Enter valid number")</script>';
      }
     
      // Purpose Validation
      
	    if (!preg_match($validCharacters,$title))
       {
		      echo '<script>alert("Digits are not allowed in purpose")</script>';
		   }
      // Description Validation
	    if (!preg_match($validCharacters,$desc)) 
      {
		    echo '<script>alert("Digits are not allowed in description")</script>';
		  }
               if($amount > 100000)
               {
                     echo '<script>alert("Amount less than 1 Lakh only allowed!")</script>';
               } 
              if(!empty('$amount') && $amount <= 100000 && $amount > 10000 && !empty('$title') && preg_match($validCharacters,$title) && !empty('$desc') && preg_match($validCharacters,$desc) && !empty('$end_date') && !empty('$filename'))
              {

                $chk="SELECT * from registration where email='$email'";
                $ch=mysqli_query($con,$chk);
                $row1=mysqli_fetch_assoc($ch);
                
                $raisedBy=$row1['fname'];
                  $sql="INSERT INTO `fundraise`(`email`, `client`, `purpose`, `desc`, `start_date`, `end_date`, `proof1`, `proof2`, `amount`) VALUES ('$email','$raisedBy','$title','$desc','$start_date','$end_date','$filename','$filename','$amount')";
                  if(mysqli_query($con,$sql))
                  {
                     echo '<script>alert("Fund raised Successfully---!")</script>';
                  }
                  else
                  {
                     echo '<script>alert("Failed")</script>';
                  }
                 
              }
              else{
                      echo '<script>alert("Failed to raise fund!")</script>';
                  }
}
?>



<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="requestAction.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
	    margin-top: 0px;
      margin-left: 540px;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
  </style>
</head>
<body>
<header>
     
	<div class="left">
		<h3>Charit<span>ABLE</span> </h3>
	</div>
  <?php 
    $e=$_SESSION['email'];	    
	include('config.php');

	$chk="select * from clientaccount where email='$e'";
    $ch=mysqli_query($con,$chk);
	$row=0;
	$row=mysqli_fetch_assoc($ch);
	if($row == 0)
	{
		
?>		
	<div id="box" class="snackbar"><?php echo "Reminder! Bank Details Not Added."; ?></div>
  <script src="welcome.js"></script>
<?php  
	}
?>
	<div class="right">
		<form action="logout.php" method="POST"> 
      <button type="submit" name="logout" class="logoutbtn">Logout</button>
</form>
		<!---<a href="logout.php" class="logoutbtn">Logout</a>------>
	</div>
</header>
    <input type="checkbox" id="check">
    <label for="check">
      <i class="fas fa-bars" id="btn"></i>
      <i class="fas fa-bars" id="cancel"></i>
    </label>
<div class="sidebar">
	  <center>
  		<?php
  		      $e=$_SESSION['email'];
  		    
  		      include('config.php');
				$sql="select * from registration where email='$e'";

						$sq=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($sq))
						{	
        ?>
							<img src="../images/<?php echo $row['img']; ?>" class="profile"> 
					
  		<h4><?php echo $row['fname'];?></h4>
  		    <?php
						}
					?>
  	</center>
      <a href="home.php">
        <i class="fas fa-desktop"></i>
        <span>Home</span>
      </a>
      <a href="profile.php">
        <i class="fas fa-user"></i>
        <span>Profile</span>
      </a>
      <a href="requestAction.php" class="active">
        <i class="fas fa-comment-dollar"></i>
        <span>Request action</span>
      </a>
      <a href="actionTaken.php">
         <i class="fas fa-calendar"></i>
        <span>Action taken</span>
      </a>
      <a href="actionHistory.php">
        <i class="fas fa-history"></i>
        <span>Recent activities</span>
      </a>
	  <!---<a href="viewAchievements.php">
        <i class="fas fa-book"></i>
        <span>Achievements</span>
      </a>---->
     <!--- <a href="#">
        <i class="fas fa-sliders-h"></i>
        <span>Services</span>
      </a>--->
      <a href="feedback.php">
        <i class="far fa-envelope"></i>
        <span>Feedback</span>
      </a>
    </div>
    <?php
if($row1 == 0)
{
?>
  <div style="text-decoration: none !important; color: red; margin-left: 370px; padding-top:50px;"><a href="bankAccDetails.php">Add Bank account details</a></div>
<?php  
}
?>
  <div class="table_responsive" style="margin-left: 370px; background-color: whitesmoke;">
  <table  style="margin-top: 90px; background-color: whitesmoke;">
  

    <thead>            
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" role="form" enctype="multipart/form-data">
                    <tr>
                      <td style="color: black;">Purpose&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="purpose" placeholder="Purpose" required><span class="error">* <?php echo $purposeErr; ?></span></td>
                      </td>
                     
                    </tr>
                    <tr>
                        <td style="color: black;">Description&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="desc" placeholder="Description"><span class="error" required>* <?php echo $descriptionErr; ?></span></td>
                    </tr>
                        <tr>
                        <td style="color: black;">End Date&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="date" value="" class="form-control mb-3" name="end_date" placeholder="End Date" required><span class="error">* <?php echo $end_dateErr; ?></span></td>
                    </tr>
                    <tr><td style="color: black;">
                    Upload Document(PDF file only)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="fileToUpload" id="fileToUpload" accept="application/pdf"/><span class="error">* <?php echo $fileToUploadErr; ?></span>
	                 </td></tr>
                     <tr>
                        <td style="color: black;">
                           Upload Document(PDF file only)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="proof2" id="proof2" accept="application/pdf"/><span class="error">* <?php echo $fileToUploadErr; ?></span>
	                     </td>
                     </tr>
                     <tr>
                        <td style="color: black;">Expected Amount&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" value="" class="form-control mb-3" name="expect_amount" placeholder="Amount"/><span class="error">* <?php echo $expect_amountErr; ?></span></td>
                     </tr>
                     <tr><td><span class="error"><?php echo $fileupload_status; ?></span></td></tr>
                    
                     <tr>
                        <td><input type="submit" name="submit" class="btn btn-primary btn-block" value="Submit"></td>
                     </tr>
          </thead>
                    </table>
   </form>
</div>  

</body>
</html>
