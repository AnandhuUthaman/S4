<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="index.css" />
  <title>CharitABLE | Index page</title>
  <style>
    .dropbtn {
      background-color: white;
      color: black;
      padding: 0px;
      font-size: 1.69rem;
      font-weight: 1rem;
      border: none;
      cursor: pointer;
    }

    .dropdown {
      margin-left: 11px;
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      z-index: 1;
    }

    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {
      background-color: #f1f1f1
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown:hover .dropbtn {
      color: #ff7300;
    }
  </style>
  <style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
      margin-left: 540px;
      background-color: white;
      color: red;
      font-size: 22px;
      font-weight: 600;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
  </style>
</head>

<body>
<div style="width:100%; height:18px; background-color:darkblue; color:black; font-size:13px; position: relative;">
    <div style="margin-left:120px; color: white;">
    &#9993 charitable@gmail.com&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&#9990 +91 6238591004&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-twitter"></i>      <i class="fa fa-facebook"></i>
    </div>
</div>    
  <header>
    <!-- ********** ###### ********** -->
    <!-- ********** nav-bar ********** -->

    <nav>
    
     
        <ul>
          <li><a href="#" class="logo">CharitABLE</a></li>
          <!--<input class="search" type="text" placeholder="Search..">-->
          <li style="padding-left: 450px;"><a href="index.php" class="active">Home</a></li>
          <li><a href="contact.php">Contact us</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="#">News</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="reg.php">Sign Up</a></li>
        </ul>
     
    </nav>
    <!-- ======================== Navigation-bar close **********======================================== -->



    <!--====================== ********** Past code ********** =========================================-->


    <!----<div class="container_box">
        <h1>Give, but <span>Give</span> until it hurts</h1>
        <p style="font-size:15px;">
          You have not lived today until you have done something for someone who can never repay you.
        </p>
        <a class="button" href="login.php">Get start</a>
       
  </div>
<!---<div id="box" class="snackbar">Index Page</div>
<script src="welcome.js"></script>--->
  </header>
  
<!-- //<?php
       //include('config.php');

       //$sql="SELECT * from events";
      // $res=mysqli_query($con,$sql);
       
      // while($row=mysqli_fetch_array($res))
        //  {

        // ?>             -->
<!--<table style="font-size:15px; margin-left:30px;">
<div style="width:330px; height:50px; background-color:white; margin-top:70px; margin-left:30px; border-left:1px solid black; border-right:1px solid black; border-top:1px solid black;">
          <H1 align="center">Donate Funds</H1>
      </div>
<div style="Width: 330px; height: 200px; background-color:white; margin-left:30px; color:black; border-left:1px solid black; border-right:1px solid black; overflow:auto">





            
            <tr>
            <td>Description:</td>
            <td><?php echo $row['description']; ?></td>
            </tr>
            <tr>
            <td>Amount needed:</td>
            <td><?php echo $row['expect_amount']; ?></td>
            </tr>
            <tr>
            <td>Last date to donate:</td>
            <td><?php echo $row['end_date']; ?></td>
            </tr>
           
            </table>
</div>
<div style="width:330px; height:60px; background-color:white; margin-left:30px; border-left:1px solid black; border-right:1px solid black; border-bottom:1px solid black;">
             <input type="button" name="donate" value="Donate now" style="width:90px; height:40px; margin-left:208px; margin-top:8px;">
      </div>

    //<?Php
         // } 
    //?>---->
 </div>  
<div style="width: 100%; height: 215px; background-color: #333; margin-top:542px; position: relative; border-top: 2px solid yellow;">

<header>
    <!-- ********** ###### ********** -->
    <!-- ********** nav-bar ********** -->

    <nav>
    
     
    <ul>
      <li><a href="#" class="logo">CharitABLE</a></li>
      <!--<input class="search" type="text" placeholder="Search..">-->
      <li style="padding-left: 450px;"><a href="index.php">Home</a></li>
      <li><a href="contact.php">Contact us</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="#">News</a></li>
      <li><a href="login.php">Login</a></li>
      <li><a href="reg.php">Sign Up</a></li>
    </ul>
 
</nav>
         <div style="width: 57%; height:130px; background-color: #333; margin-left: 33px; color: white;">
          <h2 style="font-size: 2.3rem; margin-left:0px;"><i class="fas fa-phone"></i>Contact us</h2>
          <h2>CharitABLE</h2>
          <h2>Focus on Togetherness</h2>
          <h2>charitable@gmail.com</h2>
          <h2>Ph: 6238591004</h2>
          <h2>Address: Mundakkayam, Kottayam, Kerala</h2>
          <h2>Pincode: 686513 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &copy; Copyright@2022</h2>
         </div>
         <!---<div style="width: 27%; background-color: orange; margin-left: 20px;">
          <h2 style="font-size: 2.3rem; margin-left:0px;"><i class="fas fa-phone"></i>About us</h2>
          <h2>CharitABLE</h2>
          <h2>Focus on Togetherness</h2>
          <h2>charitable@gmail.com</h2>
          <h2>Ph: 6238591004</h2>
          <h2>Address: Mundakkayam, Kottayam, Kerala</h2>
         </div>---->   
  </header>
</div>
           
</body>
</html>