<?php
session_start();
include('config.php');
$emailErr = $passwordErr = $Err_message = "";

if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit']))
{

//   // Email Validation
//  if(empty($_POST["email"]))
//  {
//      $emailErr="Email can't be blank";
//  }

// //  // Password Validation
//  if(empty($_POST["psw"]))
//  {
//      $passwordErr="Password can't be blank";
//  }

       $email = $_POST['email'];
       $psw = $_POST['psw'];
       $_SESSION['email'] = $email;
       $_SESSION['psw'] = $psw;

       if (!empty($_POST['email']) && !empty($_POST['psw'])) 
       {
          $sql = "SELECT * FROM `registration` WHERE email='$email' and psw='$psw'";
          $sql1 = "SELECT * FROM `login` WHERE email='$email' and psw='$psw'";
          $re = mysqli_query($con, $sql);
          $re1 = mysqli_query($con, $sql1);
          if ($row = mysqli_fetch_array($re)) 
          {
                     if ($row['role'] == "Admin") 
                     {
                            $_SESSION["id"] = $id;
                            $_SESSION["charitymain"] = session_id();
                            header('Location: admin/home.php');
                     }
                     if ($row['block'] == '1') 
                     {
                            //blocked accounts
                            header('Location: index.php');
                     } 
                     else 
                     {

                            if (mysqli_num_rows($re1) == 0) 
                            {

                                   if ($row['utype'] != "admin") 
                                   {
                                    if ($row['approval'] != "pending") 
                                    {
                                           $sql2 = "INSERT INTO `login`(`email`, `psw`) VALUES ('$email','$psw')";
                                           mysqli_query($con, $sql2);
 
                                    }  

                                          if ($row['role'] == "Donor") 
                                          {
                                                 if ($row['approval'] == "pending") 
                                                 {
                                                        echo '<script>alert("Pending of approval of registration")</script>';
                                                       
                                                 }  
                                                 else
                                                 {
                                                  $_SESSION["id"] = $id;
                                                  $_SESSION["charitymain"] = session_id();
 
                                                  header('Location: donor/home.php');
                                                 }
                                                 
                                          } 
                                          else if ($row['role'] == "Client") 
                                          {
                                                 if ($row['approval'] == "pending") 
                                                 {
                                                        echo '<script>alert("Pending of approval of registration")</script>';
                                                       
                                                 } 
                                                 else
                                                 {
                                                  $_SESSION["id"] = $id;
                                                  $_SESSION["charitymain"] = session_id();
 
                                                  header('Location: client/home.php');
                                                 }
                                                
                                          } 
                                          else if ($row['role'] == "Volunteer")
                                           {
                                                 if ($row['approval'] == "pending") 
                                                 {
                                                        echo '<script>alert("Pending of approval of registration")</script>';
                                                       
                                                 } 
                                                 else
                                                 {
                                                  $_SESSION["id"] = $id;
                                                  $_SESSION["charitymain"] = session_id();
 
                                                  header('Location: volunteer/home.php');
                                                 }
                                                
                                          }
                                   }
                            } 
                            else 
                            {
                                   echo '<script>alert("!----You are already logged in.Log out first----!")</script>';
                                   $sql3 = "delete from login where email='$email'";
                                   $del = mysqli_query($con, $sql3);
                            }
                     }
              }
              else
              {
                    // header("Location:?error=Invalid Email id/Password!!");
                     //echo '<script>alert("Restricted")</script>';
                     $Err_message = "Invalid Email id/Password!";
              }
       } 
       else 
       {
               //header("Location:login.php?error=Invalid Email id/Password!!"); 
               $Err_message = "Email id and Password can't be blank!";
       }
}
?>






<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">
<head>
  <meta charset="UTF8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <!-------Login form downloaded from CodingNepal------>
  <title>CharitABLE | Login Form</title>
  <link rel="stylesheet" href="login.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>

  <SCRIPT type="text/javascript">
    window.history.forward();
    function noBack() 
    {

     window.history.forward();
    }
</SCRIPT>
<script type="text/javascript" language="javascript">
        function login1() 
        {
           
                if (document.login.psw.value =="")
                {
                    alert("Enter your Password"); 
                    document.login.psw.focus();
                    return false;
                }
                return true;
        }
    </script>
<style>
    .dropbtn {
      background-color: white;
      color: black;
      padding: 0px;
      font-size: 1.12rem;
      font-weight: 1rem;
      border: none;
      cursor: pointer;
    }

    .dropdown {
      margin-left: 11px;
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      z-index: 1;
    }

    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {
      background-color: #f1f1f1
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown:hover .dropbtn {
      color: #ff7300;
    }
    .error
    {
      color: red;
      font-size: 17px;
    }
  </style>
   <style>
    .snackbar
    {
      visibility: visible;
      min-width: 250px;
      margin-top: 80px;
      margin-left: 490px;
      color: red;
      font-size: 18px;
      font-weight: 400;
      text-align: center;
      border-radius: 2px;
      padding: 16px;
      position: fixed;
    }
  </style>
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
<div style="width:100%; height:18px; background-color:darkblue; color:black; font-size:13px; position: relative;">
    <div style="margin-left:120px; color: white;">
    &#9993 charitable@gmail.com&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&#9990 +91 6238591004&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-twitter"></i>      <i class="fa fa-facebook"></i>
    </div>
</div>
<header>
      <!-- ********** ###### ********** -->
      <!-- ********** nav-bar ********** -->

      <nav>
    
     
          <ul>
                 <li><a href="#" class="logo">CharitABLE</a></li>
                 <!--<input class="search" type="text" placeholder="Search..">-->
                 <li style="padding-left: 430px;"><a href="index.php">Home</a></li>
                 <li><a href="contact.php">Contact us</a></li>
                 <li><a href="about.php">About</a></li>
                 <li><a href="#">News</a></li>
			           <li><a href="login.php" class="active">Login</a></li>
                 <li><a href="reg.php">Sign Up</a></li>
          </ul>
          
      </nav> 
     <center> <div id="box" class="snackbar"><?php echo $Err_message; ?></div></center>
             <script src="welcome.js"></script>
</header>     
      <!-- ********** ###### ********** -->
  <!-- ********** end of nav-bar ********** -->  
<center>    
  <div class="wrapper">
    <header>Login Form</header>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" name="form">
         <div class="field email">
             <div class="input-area">
                <input type="email" id="email" name="email" placeholder="Email Address">
                <i class="icon fas fa-envelope"></i>
                
             </div>
         </div>
         <div class="field password">
             <div class="input-area">
                  <input type="password" id="psw" name="psw" placeholder="Password">
                  <i class="icon fas fa-lock"></i>
                  
             </div>
                  
         </div>
         <div class="error"><span><?php echo $emailErr; ?></span></div>
         <div class="error"><span><?php echo $passwordErr; ?></span></div>
               <div class="error"><span><?php echo $Err_message; ?></span></div>
               <div class="pass-txt"><a href="forgot.php">Forgot password?</a></div>
               <input type="submit" name="submit" value="Login">
    </form>
    <div class="sign-txt" style="color: black;">Not yet member? <a href="reg.php">Signup now</a></div>
  </div></center>

<!--<div style="width: 100%; height: 200px; background-color: whitesmoke; margin-top: 45px; position: relative;">
    <div style="width:230px; height: 100px; color: indigo; font-size: 1.7rem; margin-left: 70px;"><h3>Charit<span>ABLE</span></h3></div>
</div>--->

  </body>
</html>
