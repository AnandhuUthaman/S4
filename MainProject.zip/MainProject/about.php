<!DOCTYPE html>
<html>
<head>
	<title>CharitABLE | About Us</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
	<link rel="stylesheet" type="text/css" href="about.css">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
</head>
<style>
    .dropbtn {
      display: block;
	color: white;
  background-color: #333;
	text-align: center;
	padding: 14px 16px;
	margin-top: 5px;
	margin-left: 1.7rem;
   text-decoration: none;
  
    }

    .dropdown {
      margin-left: 4px;
      position: relative;
      display: inline-block;
      background-color: #333;
    }
    .dropdown:hover{
      background-color: #111;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #333;
      min-width: 160px;
      z-index: 1;
    }

    .dropdown-content a {
      color: white;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {
      background-color: #f1f1f1
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown:hover .dropbtn {
      color: #ff7300;
    }
  </style>	
<body>
<div style="width:100%; height:30px; background-color:darkblue; color:white; font-size:13px; position: relative;">
    <div style="margin-left:120px;">&#9993 charitable@gmail.com&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&#9990 +91 6238591004&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-twitter"></i>      <i class="fas fa-facebook"></i>
</div>
<header>
      <!-- ********** ###### ********** -->
      <!-- ********** nav-bar ********** -->

      <nav>
    
     
        <ul>
          <li><a href="#" class="logo">CharitABLE</a></li>
          <!--<input class="search" type="text" placeholder="Search..">-->
          <li style="padding-left: 477px;"><a href="index.php">Home</a></li>
            <li><a href="contact.php">Contact us</a></li>
            <li><a href="about.php"  class="active">About</a></li>
            <li><a href="#">News</a></li>
		        <li><a href="login.php">Login</a></li>
			      <li><a href="reg.php">Sign Up</a></li>
          </ul>
        </div>
      </nav>
	  </header>	
      <!-- ********** ###### ********** -->
      <!-- ********** end of nav-bar ********** -->
	<div class="section">
		<div class="container">
			<div class="content-section">
				<div class="title">
					<h2>About Us</h2>
				</div>
				<div class="content">
					<h3>“You can give something and get it back in a different way, without asking for anything in exchange.”</h3>
					<p>This is an online platform for giving and taking financial and physical supports from the society.Anyone can read the informations provided in this website.After understanding the application, If you are interested in this platform, you can support to our charity activity. </p>
					<div class="button">
						<a href="login.php">Read More</a>
					</div>
				</div>
			</div>
			<div class="image-section">
				<img src="about.jpg">
			</div>
		</div>
	</div>

<div style="width: 100%; height: 200px; background-color: whitesmoke; position: relative; margin-top: 60px;">
   <div style="width:230px; height: 100px; color: indigo; font-size: 1.7rem; margin-left: 70px;"><h3>Charit<span>ABLE</span></h3></div>
</div>

</body>
</html>