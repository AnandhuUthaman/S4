<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CharitABLE | Contact us</title>
    <link rel="stylesheet" href="contact.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <style>
    .dropbtn {
      background-color: white;
      color: black;
      padding: 0px;
      font-size: 1.12rem;
      font-weight: 1rem;
      border: none;
      cursor: pointer;
    }

    .dropdown {
      margin-left: 11px;
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      z-index: 1;
    }

    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {
      background-color: #f1f1f1
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown:hover .dropbtn {
      color: #ff7300;
    }
  </style>
  </head>
  <body>
  <div style="width:100%; height:30px; background-color:darkblue; color:white; font-size:13px;">
    <div style="margin-left:120px;">&#9993 charitable@gmail.com&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&#9990 +91 6238591004&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-twitter"></i>      <i class="fas fa-facebook"></i>
  </div>
    <header>
      <!-- ********** ###### ********** -->
      <!-- ********** nav-bar ********** -->
      <nav>
    
     
        <ul>
          <li><a href="#" class="logo">CharitABLE</a></li>
          <!--<input class="search" type="text" placeholder="Search..">-->
          <li style="padding-left: 440px;"><a href="index.php">Home</a></li>
          <li><a href="contact.php" class="active">Contact us</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="#">News</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="reg.php">Sign Up</a></li>
          </ul>
        </div>
      </nav>
      </header>   

    <!--contact section start-->
    <div class="contact-section" style="margin-top: 130px;">
      <div class="contact-info">
        <div><i class="fas fa-map-marker-alt"></i>Mundakkayam, Kottayam, India</div>
        <div><i class="fas fa-envelope"></i>charitable@gmail.com</div>
        <div><i class="fas fa-phone"></i>+91 6238591004</div>
        <div><i class="fas fa-clock"></i>Mon - Fri 9:00 AM to 5:00 PM</div>
      </div>
      <div class="contact-form">
        <h2>Contact Us</h2>
        <form class="contact" action="" method="post">
          <input type="text" name="name" class="text-box" placeholder="Your Name" required>
          <input type="email" name="email" class="text-box" placeholder="Your Email" required>
          <input name="msg" rows="5" placeholder="Your Message" class="text-box" style="width:700px; height:150px;" required>
          <br><input type="submit" name="submit" class="send-btn" value="Send" style="margin-right: 580px;">
        </form>
      </div>
      
    </div>
    <!--contact section end-->
<div style="width: 100%; height: 200px; background-color: whitesmoke; margin-top:347px; position: relative;">
   <div style="width:230px; height: 100px; color: indigo; font-size: 1.9rem; margin-top: 70px; margin-left: 70px;"><h3>Charit<span>ABLE</span></h3></div>
</div>


  </body>
</html>
<?php
include('config.php');
if(isset($_POST['submit']))
{
    
    
    $email=$_POST['email'];
    $name=$_POST['name'];
    $msg=$_POST['msg'];
    echo $email;
    echo $name;
    echo $msg;

    $sql="INSERT into `contact` values('$name','$email','$msg')";
    $row=mysqli_query($con,$sql);
    if($row)
    {      
      echo '<script>alert("Thank you for contacting us.")</script>';
    }
    else
    {
      echo '<script>alert("Failed to add")</script>';
    }
}
?>  